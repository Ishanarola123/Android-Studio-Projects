/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.cprograms4future.allcprograms;

public class d {
    private String question;

    public d(String string) {
        this.question = string;
    }

    public String getQuestion() {
        return this.question;
    }
}

