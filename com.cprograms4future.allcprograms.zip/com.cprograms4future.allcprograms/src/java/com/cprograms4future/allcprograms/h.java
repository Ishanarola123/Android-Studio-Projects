/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.cprograms4future.allcprograms;

public class h {
    private String programName;

    public h(String string) {
        this.programName = string;
    }

    public String getProgramName() {
        return this.programName;
    }
}

