/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.String
 */
package com.twitter.sdk.android.core.identity;

class k
extends Exception {
    private final int a;
    private final String b;

    public k(int n2, String string, String string2) {
        super(string);
        this.a = n2;
        this.b = string2;
    }
}

