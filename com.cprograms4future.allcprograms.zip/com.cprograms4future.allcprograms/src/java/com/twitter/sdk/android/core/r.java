/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.twitter.sdk.android.core;

public class r
extends RuntimeException {
    public r(String string) {
        super(string);
    }

    public r(String string, Throwable throwable) {
        super(string, throwable);
    }
}

