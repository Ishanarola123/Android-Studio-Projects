/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 */
package com.twitter.sdk.android.tweetcomposer;

import java.io.Serializable;

public class b
implements Serializable {
    final String a;
    final String b;
    final String c;
    final String d;
    final String e;
    final String f;

    static boolean a(b b2) {
        return b2 != null && b2.a() != null && b2.a().equals((Object)"promo_image_app");
    }

    public String a() {
        return this.a;
    }
}

