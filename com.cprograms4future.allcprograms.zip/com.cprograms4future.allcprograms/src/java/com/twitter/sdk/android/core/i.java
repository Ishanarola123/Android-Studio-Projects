/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.twitter.sdk.android.core;

import d.l;

public class i<T> {
    public final T a;
    public final l b;

    public i(T t2, l l2) {
        this.a = t2;
        this.b = l2;
    }
}

