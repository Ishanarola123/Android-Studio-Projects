/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.twitter.sdk.android.core.services;

import d.b;
import d.b.f;

public interface ConfigurationService {
    @f(a="/1.1/help/configuration.json")
    public b<Object> configuration();
}

