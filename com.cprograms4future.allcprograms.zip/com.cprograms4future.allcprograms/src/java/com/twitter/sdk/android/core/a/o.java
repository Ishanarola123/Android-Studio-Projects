/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collections
 *  java.util.List
 */
package com.twitter.sdk.android.core.a;

import com.twitter.sdk.android.core.a.e;
import com.twitter.sdk.android.core.a.f;
import com.twitter.sdk.android.core.a.k;
import com.twitter.sdk.android.core.a.n;
import com.twitter.sdk.android.core.a.p;
import com.twitter.sdk.android.core.a.r;
import java.util.Collections;
import java.util.List;

public class o {
    private String A;
    private List<Integer> B = Collections.EMPTY_LIST;
    private boolean C;
    private r D;
    private boolean E;
    private List<String> F = Collections.EMPTY_LIST;
    private String G;
    private e H;
    private f a;
    private String b;
    private Object c;
    private p d;
    private p e;
    private Integer f;
    private boolean g;
    private String h;
    private long i = -1L;
    private String j;
    private String k;
    private long l;
    private String m;
    private long n;
    private String o;
    private String p;
    private k q;
    private boolean r;
    private Object s;
    private long t;
    private String u;
    private n v;
    private int w;
    private boolean x;
    private n y;
    private String z;

    public n a() {
        n n2 = new n(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j, this.k, this.l, this.m, this.n, this.o, this.p, this.q, this.r, this.s, this.t, this.u, this.v, this.w, this.x, this.y, this.z, this.A, this.B, this.C, this.D, this.E, this.F, this.G, this.H);
        return n2;
    }

    public o a(n n2) {
        this.a = n2.a;
        this.b = n2.b;
        this.c = n2.c;
        this.d = n2.d;
        this.e = n2.e;
        this.f = n2.f;
        this.g = n2.g;
        this.h = n2.h;
        this.i = n2.i;
        this.j = n2.j;
        this.k = n2.k;
        this.l = n2.l;
        this.m = n2.m;
        this.n = n2.n;
        this.o = n2.m;
        this.p = n2.p;
        this.q = n2.q;
        this.r = n2.r;
        this.s = n2.s;
        this.t = n2.t;
        this.u = n2.u;
        this.v = n2.v;
        this.w = n2.w;
        this.x = n2.x;
        this.y = n2.y;
        this.z = n2.z;
        this.A = n2.A;
        this.B = n2.B;
        this.C = n2.C;
        this.D = n2.D;
        this.E = n2.E;
        this.F = n2.F;
        this.G = n2.G;
        this.H = n2.H;
        return this;
    }

    public o a(boolean bl) {
        this.g = bl;
        return this;
    }
}

