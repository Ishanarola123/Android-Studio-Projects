/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 */
package com.twitter.sdk.android.core.a;

import java.io.Serializable;

class g
implements Serializable {
}

