/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.twitter.sdk.android.core;

public final class h {

    public static final class a {
        public static final int height = 2131296434;
        public static final int imageView = 2131296443;
        public static final int tw__allow_btn = 2131296625;
        public static final int tw__not_now_btn = 2131296648;
        public static final int tw__share_email_desc = 2131296651;
        public static final int tw__spinner = 2131296652;
        public static final int tw__web_view = 2131296667;
        public static final int width = 2131296692;
    }

    public static final class b {
        public static final int tw__activity_oauth = 2131492970;
        public static final int tw__activity_share_email = 2131492971;
    }

    public static final class c {
        public static final int tw__cacerts = 2131755008;
    }

    public static final class d {
        public static final int kit_name = 2131820671;
        public static final int tw__allow_btn_txt = 2131820716;
        public static final int tw__login_btn_txt = 2131820723;
        public static final int tw__not_now_btn_txt = 2131820725;
        public static final int tw__share_email_desc = 2131820735;
        public static final int tw__share_email_title = 2131820736;
    }

    public static final class e {
        public static final int[] tw__AspectRatioImageView = new int[]{2130969131, 2130969132};
        public static final int tw__AspectRatioImageView_tw__image_aspect_ratio = 0;
        public static final int tw__AspectRatioImageView_tw__image_dimension_to_adjust = 1;
    }

}

