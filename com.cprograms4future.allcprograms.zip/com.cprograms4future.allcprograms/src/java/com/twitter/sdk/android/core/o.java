/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.twitter.sdk.android.core;

import com.twitter.sdk.android.core.r;

public class o
extends r {
    public o(String string) {
        super(string);
    }

    public o(String string, Throwable throwable) {
        super(string, throwable);
    }
}

