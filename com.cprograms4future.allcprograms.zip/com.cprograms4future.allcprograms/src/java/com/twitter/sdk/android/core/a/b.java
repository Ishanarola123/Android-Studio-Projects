/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.List
 */
package com.twitter.sdk.android.core.a;

import com.google.a.a.c;
import com.twitter.sdk.android.core.a.a;
import java.util.List;

public class b {
    @c(a="errors")
    public final List<a> a;
}

