/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.twitter.sdk.android.core.a;

import com.google.a.a.c;

public class h {
    @c(a="url")
    public final String a;
    @c(a="alt")
    public final String b;
}

