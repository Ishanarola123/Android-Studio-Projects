/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.twitter.sdk.android.core.a;

import com.google.a.a.c;

public class a {
    @c(a="code")
    public final int a;
}

