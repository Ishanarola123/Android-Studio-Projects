/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 */
package com.twitter.sdk.android.core.a;

import com.google.a.a.c;
import java.io.Serializable;

public class r
implements Serializable {
    @c(a="email")
    public final String a;
    @c(a="name")
    public final String b;
    @c(a="profile_image_url_https")
    public final String c;
    @c(a="screen_name")
    public final String d;
}

