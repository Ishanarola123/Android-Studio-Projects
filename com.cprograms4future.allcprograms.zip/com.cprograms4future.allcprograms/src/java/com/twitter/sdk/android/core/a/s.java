/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.twitter.sdk.android.core.a;

import com.google.a.a.c;

public class s {
    @c(a="id_str")
    public final String a;
}

