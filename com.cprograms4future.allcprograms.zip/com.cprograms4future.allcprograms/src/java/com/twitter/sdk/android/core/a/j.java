/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 */
package com.twitter.sdk.android.core.a;

import com.google.a.a.c;
import com.twitter.sdk.android.core.a.q;
import com.twitter.sdk.android.core.a.t;

public class j
extends q {
    @c(a="id")
    public final long a;
    @c(a="media_url_https")
    public final String b;
    @c(a="type")
    public final String c;
    @c(a="video_info")
    public final t d;
}

