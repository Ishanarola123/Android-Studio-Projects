/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.util.concurrent.ScheduledExecutorService
 */
package com.twitter.sdk.android.core.internal.scribe;

import a.a.a.a.a.d.d;
import a.a.a.a.a.d.e;
import android.content.Context;
import com.twitter.sdk.android.core.internal.scribe.f;
import java.util.concurrent.ScheduledExecutorService;

class i
extends e<f> {
    public i(Context context, a.a.a.a.a.d.i<f> i2, d d2, ScheduledExecutorService scheduledExecutorService) {
        super(context, i2, d2, scheduledExecutorService);
    }

    public void a(f f2) {
        this.a(f2, false);
    }
}

