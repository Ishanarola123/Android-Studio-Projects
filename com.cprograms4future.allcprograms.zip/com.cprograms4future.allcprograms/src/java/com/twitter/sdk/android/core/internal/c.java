/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.twitter.sdk.android.core.internal;

import com.twitter.sdk.android.core.j;

public interface c<T extends j> {
    public void a(T var1);
}

