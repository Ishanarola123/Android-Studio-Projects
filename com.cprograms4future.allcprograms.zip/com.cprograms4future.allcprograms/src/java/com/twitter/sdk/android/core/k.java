/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Long
 *  java.lang.Object
 *  java.util.Map
 */
package com.twitter.sdk.android.core;

import com.twitter.sdk.android.core.j;
import java.util.Map;

public interface k<T extends j> {
    public T a(long var1);

    public void a(T var1);

    public T b();

    public Map<Long, T> c();

    public void c(long var1);
}

