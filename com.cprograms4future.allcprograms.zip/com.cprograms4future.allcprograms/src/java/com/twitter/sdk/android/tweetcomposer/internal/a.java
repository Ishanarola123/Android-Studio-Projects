/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.twitter.sdk.android.tweetcomposer.internal;

import com.google.a.a.c;

public class a {
    @c(a="card_uri")
    public final String a;
}

