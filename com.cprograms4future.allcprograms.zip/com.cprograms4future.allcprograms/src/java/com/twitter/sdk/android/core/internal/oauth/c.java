/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.twitter.sdk.android.core.p
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package com.twitter.sdk.android.core.internal.oauth;

import com.twitter.sdk.android.core.internal.oauth.d;
import com.twitter.sdk.android.core.n;
import com.twitter.sdk.android.core.p;
import java.util.Map;

public class c {
    public String a(n n2, p p2, String string, String string2, String string3, Map<String, String> map) {
        return this.b(n2, p2, string, string2, string3, map).a();
    }

    d b(n n2, p p2, String string, String string2, String string3, Map<String, String> map) {
        d d2 = new d(n2, p2, string, string2, string3, map);
        return d2;
    }
}

