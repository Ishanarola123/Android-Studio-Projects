/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.twitter.sdk.android.tweetcomposer;

import com.twitter.sdk.android.core.internal.scribe.c;
import com.twitter.sdk.android.core.internal.scribe.j;
import com.twitter.sdk.android.tweetcomposer.b;

final class n {
    static final c.a a = new c.a().a("tfw").b("android").c("composer");

    static j a(b b2) {
        return new j.a().a(0).a(new j.b(8)).a();
    }
}

