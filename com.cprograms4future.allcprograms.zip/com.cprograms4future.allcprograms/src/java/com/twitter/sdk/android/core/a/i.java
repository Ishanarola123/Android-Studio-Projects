/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.twitter.sdk.android.core.a;

import com.google.a.a.c;

public class i {
    @c(a="media_id")
    public final long a;
}

