/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.twitter.sdk.android.core.a;

import com.twitter.sdk.android.core.a.c;

public class e {
    @com.google.a.a.c(a="binding_values")
    public final c a;
    @com.google.a.a.c(a="name")
    public final String b;
}

