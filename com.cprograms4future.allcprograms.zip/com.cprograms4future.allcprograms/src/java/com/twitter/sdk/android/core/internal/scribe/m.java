/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.twitter.sdk.android.core.internal.scribe.a
 *  com.twitter.sdk.android.core.p
 *  com.twitter.sdk.android.core.q
 *  java.lang.Object
 *  java.lang.String
 */
package com.twitter.sdk.android.core.internal.scribe;

import a.a.a.a.i;
import com.twitter.sdk.android.core.e;
import com.twitter.sdk.android.core.internal.scribe.a;
import com.twitter.sdk.android.core.j;
import com.twitter.sdk.android.core.k;
import com.twitter.sdk.android.core.p;
import com.twitter.sdk.android.core.q;

public class m {
    private static a a;

    public static a a() {
        return a;
    }

    public static void a(q q2, k<? extends j<p>> k2, e e2, a.a.a.a.a.b.m m2) {
        a a2;
        a = a2 = new a((i)q2, "TwitterCore", k2, e2, m2);
    }
}

