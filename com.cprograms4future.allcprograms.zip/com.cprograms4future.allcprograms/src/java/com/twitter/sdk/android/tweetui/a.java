/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.twitter.sdk.android.core.c
 *  java.lang.Object
 */
package com.twitter.sdk.android.tweetui;

import com.twitter.sdk.android.core.a.n;
import com.twitter.sdk.android.core.c;

class a {
    protected c<n> a;

    a(c<n> c2) {
        this.a = c2;
    }

    c<n> a() {
        return this.a;
    }
}

