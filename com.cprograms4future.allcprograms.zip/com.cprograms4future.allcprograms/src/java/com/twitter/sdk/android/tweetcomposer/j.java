/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.twitter.sdk.android.tweetcomposer;

public final class j {

    public static final class a {
        public static final int tw__blue_default = 2131099839;
        public static final int tw__blue_pressed = 2131099840;
        public static final int tw__blue_pressed_light = 2131099841;
        public static final int tw__composer_black = 2131099842;
        public static final int tw__composer_blue = 2131099843;
        public static final int tw__composer_blue_text = 2131099844;
        public static final int tw__composer_deep_gray = 2131099845;
        public static final int tw__composer_light_gray = 2131099846;
        public static final int tw__composer_red = 2131099847;
        public static final int tw__composer_white = 2131099848;
        public static final int tw__light_gray = 2131099851;
        public static final int tw__solid_white = 2131099854;
        public static final int tw__transparent = 2131099855;
    }

    public static final class b {
        public static final int tw__btn_bar_margin_left = 2131165438;
        public static final int tw__btn_bar_margin_right = 2131165439;
        public static final int tw__card_font_size_medium = 2131165440;
        public static final int tw__card_font_size_small = 2131165441;
        public static final int tw__card_maximum_width = 2131165442;
        public static final int tw__card_radius_medium = 2131165443;
        public static final int tw__card_radius_small = 2131165444;
        public static final int tw__card_spacing_large = 2131165445;
        public static final int tw__card_spacing_medium = 2131165446;
        public static final int tw__card_spacing_small = 2131165447;
        public static final int tw__composer_avatar_size = 2131165476;
        public static final int tw__composer_char_count_height = 2131165477;
        public static final int tw__composer_close_size = 2131165478;
        public static final int tw__composer_divider_height = 2131165479;
        public static final int tw__composer_font_size_small = 2131165480;
        public static final int tw__composer_logo_height = 2131165481;
        public static final int tw__composer_logo_width = 2131165482;
        public static final int tw__composer_spacing_large = 2131165483;
        public static final int tw__composer_spacing_medium = 2131165484;
        public static final int tw__composer_spacing_small = 2131165485;
        public static final int tw__composer_tweet_btn_height = 2131165486;
        public static final int tw__composer_tweet_btn_radius = 2131165487;
        public static final int tw__login_btn_drawable_padding = 2131165493;
        public static final int tw__login_btn_height = 2131165494;
        public static final int tw__login_btn_left_padding = 2131165495;
        public static final int tw__login_btn_radius = 2131165496;
        public static final int tw__login_btn_right_padding = 2131165497;
        public static final int tw__login_btn_text_size = 2131165498;
        public static final int tw__padding_permission_horizontal_container = 2131165501;
        public static final int tw__padding_permission_vertical_container = 2131165502;
        public static final int tw__permission_description_text_size = 2131165503;
        public static final int tw__permission_title_text_size = 2131165504;
    }

    public static final class c {
        public static final int height = 2131296434;
        public static final int imageView = 2131296443;
        public static final int tw__allow_btn = 2131296625;
        public static final int tw__app_image = 2131296626;
        public static final int tw__app_info_layout = 2131296627;
        public static final int tw__app_install_button = 2131296628;
        public static final int tw__app_name = 2131296629;
        public static final int tw__app_store_name = 2131296630;
        public static final int tw__author_avatar = 2131296633;
        public static final int tw__card_view = 2131296634;
        public static final int tw__char_count = 2131296635;
        public static final int tw__composer_close = 2131296636;
        public static final int tw__composer_header = 2131296637;
        public static final int tw__composer_profile_divider = 2131296638;
        public static final int tw__composer_scroll_view = 2131296639;
        public static final int tw__composer_toolbar = 2131296640;
        public static final int tw__composer_toolbar_divider = 2131296641;
        public static final int tw__composer_view = 2131296642;
        public static final int tw__edit_tweet = 2131296645;
        public static final int tw__not_now_btn = 2131296648;
        public static final int tw__post_tweet = 2131296649;
        public static final int tw__share_email_desc = 2131296651;
        public static final int tw__spinner = 2131296652;
        public static final int tw__twitter_logo = 2131296664;
        public static final int tw__web_view = 2131296667;
        public static final int width = 2131296692;
    }

    public static final class d {
        public static final int tw__activity_composer = 2131492969;
        public static final int tw__activity_oauth = 2131492970;
        public static final int tw__activity_share_email = 2131492971;
        public static final int tw__app_card = 2131492972;
        public static final int tw__composer_view = 2131492973;
    }

    public static final class e {
        public static final int ComposerDark = 2131886283;
        public static final int ComposerLight = 2131886284;
        public static final int tw__Button = 2131886660;
        public static final int tw__ButtonBar = 2131886662;
        public static final int tw__Button_Light = 2131886661;
        public static final int tw__CardAppInfoLayout = 2131886663;
        public static final int tw__CardAppName = 2131886664;
        public static final int tw__CardAppStoreName = 2131886665;
        public static final int tw__CardInstallButton = 2131886666;
        public static final int tw__ComposerAvatar = 2131886668;
        public static final int tw__ComposerCharCount = 2131886669;
        public static final int tw__ComposerCharCountOverflow = 2131886670;
        public static final int tw__ComposerClose = 2131886671;
        public static final int tw__ComposerDivider = 2131886672;
        public static final int tw__ComposerToolbar = 2131886673;
        public static final int tw__ComposerTweetButton = 2131886674;
        public static final int tw__EditTweet = 2131886675;
        public static final int tw__Permission_Container = 2131886676;
        public static final int tw__Permission_Description = 2131886677;
        public static final int tw__Permission_Title = 2131886678;
    }

}

