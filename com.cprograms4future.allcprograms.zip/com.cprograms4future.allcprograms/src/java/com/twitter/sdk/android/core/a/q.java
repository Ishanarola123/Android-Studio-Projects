/*
 * Decompiled with CFR 0.0.
 */
package com.twitter.sdk.android.core.a;

import com.twitter.sdk.android.core.a.g;

public class q
extends g {
}

