/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.twitter.sdk.android.core.internal.oauth;

import com.google.a.a.c;

class b {
    @c(a="guest_token")
    public final String a;
}

