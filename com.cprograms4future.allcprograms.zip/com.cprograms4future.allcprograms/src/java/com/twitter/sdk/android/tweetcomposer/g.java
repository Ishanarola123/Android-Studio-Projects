/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.twitter.sdk.android.tweetcomposer;

import com.twitter.sdk.android.tweetcomposer.b;

interface g {
    public void a(b var1);

    public void a(b var1, String var2);
}

