/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.github.clans.fab;

public final class b {

    public static final class a {
        public static final int fab_scale_down = 2130771984;
        public static final int fab_scale_up = 2130771985;
        public static final int fab_slide_in_from_left = 2130771986;
        public static final int fab_slide_in_from_right = 2130771987;
        public static final int fab_slide_out_to_left = 2130771988;
        public static final int fab_slide_out_to_right = 2130771989;
    }

    public static final class b {
        public static final int fab_size_mini = 2131165344;
        public static final int fab_size_normal = 2131165345;
        public static final int labels_text_size = 2131165359;
    }

    public static final class c {
        public static final int fab_add = 2131230863;
    }

    public static final class d {
        public static final int down = 2131296391;
        public static final int end = 2131296399;
        public static final int fab_label = 2131296414;
        public static final int left = 2131296454;
        public static final int marquee = 2131296465;
        public static final int middle = 2131296478;
        public static final int mini = 2131296479;
        public static final int none = 2131296519;
        public static final int normal = 2131296520;
        public static final int right = 2131296545;
        public static final int start = 2131296586;
        public static final int up = 2131296679;
    }

    public static final class e {
        public static final int[] FloatingActionButton = new int[]{2130968631, 2130968632, 2130968640, 2130968777, 2130968795, 2130968796, 2130968797, 2130968798, 2130968799, 2130968800, 2130968801, 2130968802, 2130968803, 2130968804, 2130968805, 2130968806, 2130968807, 2130968808, 2130968809, 2130968810, 2130968811, 2130968812, 2130968813, 2130968814, 2130968815, 2130968816, 2130968844, 2130968852, 2130968916, 2130968982, 2130968992, 2130969005, 2130969137};
        public static final int FloatingActionButton_backgroundTint = 0;
        public static final int FloatingActionButton_backgroundTintMode = 1;
        public static final int FloatingActionButton_borderWidth = 2;
        public static final int FloatingActionButton_elevation = 3;
        public static final int FloatingActionButton_fabCustomSize = 4;
        public static final int FloatingActionButton_fabSize = 5;
        public static final int FloatingActionButton_fab_colorDisabled = 6;
        public static final int FloatingActionButton_fab_colorNormal = 7;
        public static final int FloatingActionButton_fab_colorPressed = 8;
        public static final int FloatingActionButton_fab_colorRipple = 9;
        public static final int FloatingActionButton_fab_elevationCompat = 10;
        public static final int FloatingActionButton_fab_hideAnimation = 11;
        public static final int FloatingActionButton_fab_label = 12;
        public static final int FloatingActionButton_fab_progress = 13;
        public static final int FloatingActionButton_fab_progress_backgroundColor = 14;
        public static final int FloatingActionButton_fab_progress_color = 15;
        public static final int FloatingActionButton_fab_progress_indeterminate = 16;
        public static final int FloatingActionButton_fab_progress_max = 17;
        public static final int FloatingActionButton_fab_progress_showBackground = 18;
        public static final int FloatingActionButton_fab_shadowColor = 19;
        public static final int FloatingActionButton_fab_shadowRadius = 20;
        public static final int FloatingActionButton_fab_shadowXOffset = 21;
        public static final int FloatingActionButton_fab_shadowYOffset = 22;
        public static final int FloatingActionButton_fab_showAnimation = 23;
        public static final int FloatingActionButton_fab_showShadow = 24;
        public static final int FloatingActionButton_fab_size = 25;
        public static final int FloatingActionButton_hideMotionSpec = 26;
        public static final int FloatingActionButton_hoveredFocusedTranslationZ = 27;
        public static final int FloatingActionButton_maxImageSize = 28;
        public static final int FloatingActionButton_pressedTranslationZ = 29;
        public static final int FloatingActionButton_rippleColor = 30;
        public static final int FloatingActionButton_showMotionSpec = 31;
        public static final int FloatingActionButton_useCompatPadding = 32;
        public static final int[] FloatingActionMenu = new int[]{2130968919, 2130968920, 2130968921, 2130968922, 2130968923, 2130968924, 2130968925, 2130968926, 2130968927, 2130968928, 2130968929, 2130968930, 2130968931, 2130968932, 2130968933, 2130968934, 2130968935, 2130968936, 2130968937, 2130968938, 2130968939, 2130968940, 2130968941, 2130968942, 2130968943, 2130968944, 2130968945, 2130968946, 2130968947, 2130968948, 2130968949, 2130968950, 2130968951, 2130968952, 2130968953, 2130968954, 2130968955, 2130968956};
        public static final int FloatingActionMenu_menu_animationDelayPerItem = 0;
        public static final int FloatingActionMenu_menu_backgroundColor = 1;
        public static final int FloatingActionMenu_menu_buttonSpacing = 2;
        public static final int FloatingActionMenu_menu_buttonToggleAnimation = 3;
        public static final int FloatingActionMenu_menu_colorNormal = 4;
        public static final int FloatingActionMenu_menu_colorPressed = 5;
        public static final int FloatingActionMenu_menu_colorRipple = 6;
        public static final int FloatingActionMenu_menu_fab_hide_animation = 7;
        public static final int FloatingActionMenu_menu_fab_label = 8;
        public static final int FloatingActionMenu_menu_fab_show_animation = 9;
        public static final int FloatingActionMenu_menu_fab_size = 10;
        public static final int FloatingActionMenu_menu_icon = 11;
        public static final int FloatingActionMenu_menu_labels_colorNormal = 12;
        public static final int FloatingActionMenu_menu_labels_colorPressed = 13;
        public static final int FloatingActionMenu_menu_labels_colorRipple = 14;
        public static final int FloatingActionMenu_menu_labels_cornerRadius = 15;
        public static final int FloatingActionMenu_menu_labels_ellipsize = 16;
        public static final int FloatingActionMenu_menu_labels_hideAnimation = 17;
        public static final int FloatingActionMenu_menu_labels_margin = 18;
        public static final int FloatingActionMenu_menu_labels_maxLines = 19;
        public static final int FloatingActionMenu_menu_labels_padding = 20;
        public static final int FloatingActionMenu_menu_labels_paddingBottom = 21;
        public static final int FloatingActionMenu_menu_labels_paddingLeft = 22;
        public static final int FloatingActionMenu_menu_labels_paddingRight = 23;
        public static final int FloatingActionMenu_menu_labels_paddingTop = 24;
        public static final int FloatingActionMenu_menu_labels_position = 25;
        public static final int FloatingActionMenu_menu_labels_showAnimation = 26;
        public static final int FloatingActionMenu_menu_labels_showShadow = 27;
        public static final int FloatingActionMenu_menu_labels_singleLine = 28;
        public static final int FloatingActionMenu_menu_labels_style = 29;
        public static final int FloatingActionMenu_menu_labels_textColor = 30;
        public static final int FloatingActionMenu_menu_labels_textSize = 31;
        public static final int FloatingActionMenu_menu_openDirection = 32;
        public static final int FloatingActionMenu_menu_shadowColor = 33;
        public static final int FloatingActionMenu_menu_shadowRadius = 34;
        public static final int FloatingActionMenu_menu_shadowXOffset = 35;
        public static final int FloatingActionMenu_menu_shadowYOffset = 36;
        public static final int FloatingActionMenu_menu_showShadow = 37;
    }

}

