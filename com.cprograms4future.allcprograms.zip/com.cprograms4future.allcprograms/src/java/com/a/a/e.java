/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.a.a;

public interface e {
    public void a();

    public void b();
}

