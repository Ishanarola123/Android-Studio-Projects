/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  com.a.a.d$1
 *  java.lang.Object
 *  java.lang.String
 */
package com.a.a;

import android.graphics.Bitmap;
import com.a.a.d;

public interface d {
    public static final d a = new 1();

    public int a();

    public Bitmap a(String var1);

    public void a(String var1, Bitmap var2);

    public int b();

    public void clear();
}

