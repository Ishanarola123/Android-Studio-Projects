/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.drawable.Drawable
 *  java.lang.Object
 */
package com.a.a;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import com.a.a.t;

public interface ac {
    public void a(Bitmap var1, t.d var2);

    public void a(Drawable var1);

    public void b(Drawable var1);
}

