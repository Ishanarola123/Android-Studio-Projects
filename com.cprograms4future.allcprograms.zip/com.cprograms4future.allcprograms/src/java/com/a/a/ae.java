/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.lang.Object
 *  java.lang.String
 */
package com.a.a;

import android.graphics.Bitmap;

public interface ae {
    public Bitmap a(Bitmap var1);

    public String a();
}

