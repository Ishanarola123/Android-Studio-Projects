/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 */
package com.firebase.ui.auth.ui;

import android.os.Bundle;
import com.firebase.ui.auth.ui.a;
import com.firebase.ui.auth.ui.h;

public class b
extends h {
    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.a.a();
    }
}

