/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.Bundle
 *  android.support.v4.app.g
 */
package com.firebase.ui.auth.ui;

import android.content.Intent;
import android.os.Bundle;
import com.firebase.ui.auth.ui.g;

public class f
extends android.support.v4.app.g {
    protected g a;

    public void a(int n2, Intent intent) {
        this.a.a(n2, intent);
    }

    public void b_(Bundle bundle) {
        super.b_(bundle);
        this.a = new g(this);
    }

    public void x() {
        super.x();
        this.a.d();
    }
}

