/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  java.lang.Object
 *  java.lang.String
 */
package com.firebase.ui.auth.a;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.firebase.ui.auth.b;

public interface d {
    public String a(Context var1);

    public void a(int var1, int var2, Intent var3);

    public void a(Activity var1);

    public void a(a var1);

    public String b();

    public static interface a {
        public void a(b var1);

        public void b(Bundle var1);
    }

}

