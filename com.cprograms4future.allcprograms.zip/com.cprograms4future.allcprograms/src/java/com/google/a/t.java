/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.google.a;

import com.google.a.p;

public final class t
extends p {
    public t(String string) {
        super(string);
    }

    public t(String string, Throwable throwable) {
        super(string, throwable);
    }

    public t(Throwable throwable) {
        super(throwable);
    }
}

