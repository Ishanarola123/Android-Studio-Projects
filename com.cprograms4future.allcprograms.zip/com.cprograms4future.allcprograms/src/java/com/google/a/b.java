/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 */
package com.google.a;

import com.google.a.c;

public interface b {
    public boolean a(c var1);

    public boolean a(Class<?> var1);
}

