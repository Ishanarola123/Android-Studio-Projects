/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.google.a;

import com.google.a.p;

public final class m
extends p {
    public m(String string) {
        super(string);
    }

    public m(Throwable throwable) {
        super(throwable);
    }
}

