/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.google.a;

import com.google.a.l;

public final class n
extends l {
    public static final n a = new n();

    public boolean equals(Object object) {
        return this == object || object instanceof n;
        {
        }
    }

    public int hashCode() {
        return n.class.hashCode();
    }
}

