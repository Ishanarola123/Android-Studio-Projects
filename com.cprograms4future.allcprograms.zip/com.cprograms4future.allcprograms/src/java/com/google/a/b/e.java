/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 */
package com.google.a.b;

import com.google.a.d.a;
import java.io.IOException;

public abstract class e {
    public static e a;

    public abstract void a(a var1) throws IOException;
}

