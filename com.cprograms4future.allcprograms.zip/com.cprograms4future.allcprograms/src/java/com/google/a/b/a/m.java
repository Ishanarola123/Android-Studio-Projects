/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.a.b.a.m$1
 *  com.google.a.b.a.m$10
 *  com.google.a.b.a.m$11
 *  com.google.a.b.a.m$12
 *  com.google.a.b.a.m$13
 *  com.google.a.b.a.m$14
 *  com.google.a.b.a.m$15
 *  com.google.a.b.a.m$16
 *  com.google.a.b.a.m$17
 *  com.google.a.b.a.m$18
 *  com.google.a.b.a.m$19
 *  com.google.a.b.a.m$2
 *  com.google.a.b.a.m$20
 *  com.google.a.b.a.m$21
 *  com.google.a.b.a.m$22
 *  com.google.a.b.a.m$23
 *  com.google.a.b.a.m$24
 *  com.google.a.b.a.m$25
 *  com.google.a.b.a.m$26
 *  com.google.a.b.a.m$27
 *  com.google.a.b.a.m$28
 *  com.google.a.b.a.m$29
 *  com.google.a.b.a.m$3
 *  com.google.a.b.a.m$31
 *  com.google.a.b.a.m$32
 *  com.google.a.b.a.m$33
 *  com.google.a.b.a.m$34
 *  com.google.a.b.a.m$35
 *  com.google.a.b.a.m$36
 *  com.google.a.b.a.m$4
 *  com.google.a.b.a.m$5
 *  com.google.a.b.a.m$6
 *  com.google.a.b.a.m$7
 *  com.google.a.b.a.m$8
 *  com.google.a.b.a.m$9
 *  com.google.a.w
 *  com.google.a.x
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Integer
 *  java.lang.NoSuchFieldError
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.lang.StringBuilder
 *  java.math.BigDecimal
 *  java.math.BigInteger
 *  java.net.InetAddress
 *  java.net.URI
 *  java.net.URL
 *  java.util.BitSet
 *  java.util.Calendar
 *  java.util.Currency
 *  java.util.GregorianCalendar
 *  java.util.Locale
 *  java.util.UUID
 *  java.util.concurrent.atomic.AtomicBoolean
 *  java.util.concurrent.atomic.AtomicInteger
 *  java.util.concurrent.atomic.AtomicIntegerArray
 */
package com.google.a.b.a;

import com.google.a.b.a.m;
import com.google.a.c.a;
import com.google.a.d.b;
import com.google.a.l;
import com.google.a.w;
import com.google.a.x;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.URI;
import java.net.URL;
import java.util.BitSet;
import java.util.Calendar;
import java.util.Currency;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerArray;

public final class m {
    public static final w<String> A;
    public static final w<BigDecimal> B;
    public static final w<BigInteger> C;
    public static final x D;
    public static final w<StringBuilder> E;
    public static final x F;
    public static final w<StringBuffer> G;
    public static final x H;
    public static final w<URL> I;
    public static final x J;
    public static final w<URI> K;
    public static final x L;
    public static final w<InetAddress> M;
    public static final x N;
    public static final w<UUID> O;
    public static final x P;
    public static final w<Currency> Q;
    public static final x R;
    public static final x S;
    public static final w<Calendar> T;
    public static final x U;
    public static final w<Locale> V;
    public static final x W;
    public static final w<l> X;
    public static final x Y;
    public static final x Z;
    public static final w<Class> a;
    public static final x b;
    public static final w<BitSet> c;
    public static final x d;
    public static final w<Boolean> e;
    public static final w<Boolean> f;
    public static final x g;
    public static final w<Number> h;
    public static final x i;
    public static final w<Number> j;
    public static final x k;
    public static final w<Number> l;
    public static final x m;
    public static final w<AtomicInteger> n;
    public static final x o;
    public static final w<AtomicBoolean> p;
    public static final x q;
    public static final w<AtomicIntegerArray> r;
    public static final x s;
    public static final w<Number> t;
    public static final w<Number> u;
    public static final w<Number> v;
    public static final w<Number> w;
    public static final x x;
    public static final w<Character> y;
    public static final x z;

    static {
        a = new 32();
        b = m.a(Class.class, a);
        c = new 33();
        d = m.a(BitSet.class, c);
        e = new 34();
        f = new 35();
        g = m.a(Boolean.TYPE, Boolean.class, e);
        h = new 36();
        i = m.a(Byte.TYPE, Byte.class, h);
        j = new 2();
        k = m.a(Short.TYPE, Short.class, j);
        l = new 3();
        m = m.a(Integer.TYPE, Integer.class, l);
        n = new 1().a();
        o = m.a(AtomicInteger.class, n);
        p = new 12().a();
        q = m.a(AtomicBoolean.class, p);
        r = new 23().a();
        s = m.a(AtomicIntegerArray.class, r);
        t = new 4();
        u = new 5();
        v = new 6();
        w = new 7();
        x = m.a(Number.class, w);
        y = new 8();
        z = m.a(Character.TYPE, Character.class, y);
        A = new 9();
        B = new 10();
        C = new 11();
        D = m.a(String.class, A);
        E = new 13();
        F = m.a(StringBuilder.class, E);
        G = new 14();
        H = m.a(StringBuffer.class, G);
        I = new 15();
        J = m.a(URL.class, I);
        K = new 16();
        L = m.a(URI.class, K);
        M = new 17();
        N = m.b(InetAddress.class, M);
        O = new 18();
        P = m.a(UUID.class, O);
        Q = new 31().a();
        R = m.a(Currency.class, Q);
        S = new 19();
        T = new 20();
        U = m.b(Calendar.class, GregorianCalendar.class, T);
        V = new 21();
        W = m.a(Locale.class, V);
        X = new 22();
        Y = m.b(l.class, X);
        Z = new 24();
    }

    public static <TT> x a(a<TT> a2, w<TT> w2) {
        return new 25(a2, w2);
    }

    public static <TT> x a(Class<TT> class_, w<TT> w2) {
        return new 26(class_, w2);
    }

    public static <TT> x a(Class<TT> class_, Class<TT> class_2, w<? super TT> w2) {
        return new 27(class_, class_2, w2);
    }

    public static <T1> x b(Class<T1> class_, w<T1> w2) {
        return new 29(class_, w2);
    }

    public static <TT> x b(Class<TT> class_, Class<? extends TT> class_2, w<? super TT> w2) {
        return new 28(class_, class_2, w2);
    }

}

