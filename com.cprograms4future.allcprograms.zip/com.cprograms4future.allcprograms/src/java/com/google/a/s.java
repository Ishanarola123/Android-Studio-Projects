/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.reflect.Type
 */
package com.google.a;

import com.google.a.l;
import com.google.a.r;
import java.lang.reflect.Type;

public interface s<T> {
    public l a(T var1, Type var2, r var3);
}

