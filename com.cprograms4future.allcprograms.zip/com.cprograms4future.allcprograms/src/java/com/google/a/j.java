/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.reflect.Type
 */
package com.google.a;

import com.google.a.l;
import com.google.a.p;
import java.lang.reflect.Type;

public interface j {
    public <T> T a(l var1, Type var2) throws p;
}

