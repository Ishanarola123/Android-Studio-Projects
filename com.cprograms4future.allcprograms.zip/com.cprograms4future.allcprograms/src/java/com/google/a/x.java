/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.google.a;

import com.google.a.c.a;
import com.google.a.f;
import com.google.a.w;

public interface x {
    public <T> w<T> a(f var1, a<T> var2);
}

