/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.reflect.Field
 */
package com.google.a;

import com.google.a.b.a;
import java.lang.reflect.Field;

public final class c {
    private final Field a;

    public c(Field field) {
        a.a(field);
        this.a = field;
    }
}

