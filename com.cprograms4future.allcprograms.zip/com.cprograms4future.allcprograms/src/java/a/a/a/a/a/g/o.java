/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a.a.a.a.a.g;

public class o {
    public final String a;
    public final String b;
    public final String c;
    public final boolean d;
    public final String e;
    public final boolean f;
    public final String g;

    public o(String string, String string2, String string3, boolean bl, String string4, boolean bl2, String string5) {
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = bl;
        this.e = string4;
        this.f = bl2;
        this.g = string5;
    }
}

