/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a.a.a.a.a.g;

import a.a.a.a.a.g.r;
import a.a.a.a.a.g.t;

public interface s {
    public t a();

    public t a(r var1);
}

