/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a.a.a.a.a.c;

public interface b<T> {
    public void c(T var1);

    public boolean c();
}

