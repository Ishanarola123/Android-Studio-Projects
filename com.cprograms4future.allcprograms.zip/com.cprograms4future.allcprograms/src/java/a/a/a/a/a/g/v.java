/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package a.a.a.a.a.g;

import a.a.a.a.a.b.j;
import a.a.a.a.a.g.t;
import org.json.JSONException;
import org.json.JSONObject;

public interface v {
    public t a(j var1, JSONObject var2) throws JSONException;
}

