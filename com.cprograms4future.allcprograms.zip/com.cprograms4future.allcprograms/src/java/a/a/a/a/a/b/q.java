/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.System
 */
package a.a.a.a.a.b;

import a.a.a.a.a.b.j;

public class q
implements j {
    @Override
    public long a() {
        return System.currentTimeMillis();
    }
}

