/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a.a.a.a.a.f;

public interface e<T> {
    public String a(T var1);

    public T b(String var1);
}

