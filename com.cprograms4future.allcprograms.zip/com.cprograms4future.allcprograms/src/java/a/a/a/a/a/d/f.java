/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a.a.a.a.a.d;

public interface f<T> {
    public void a(T var1);

    public void b();
}

