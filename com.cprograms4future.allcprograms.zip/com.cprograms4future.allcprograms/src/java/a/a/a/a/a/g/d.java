/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 */
package a.a.a.a.a.g;

import a.a.a.a.a.g.n;
import a.a.a.a.k;
import java.util.Collection;

public class d {
    public final String a;
    public final String b;
    public final String c;
    public final String d;
    public final String e;
    public final String f;
    public final int g;
    public final String h;
    public final String i;
    public final n j;
    public final Collection<k> k;

    public d(String string, String string2, String string3, String string4, String string5, String string6, int n2, String string7, String string8, n n3, Collection<k> collection) {
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = string4;
        this.e = string5;
        this.f = string6;
        this.g = n2;
        this.h = string7;
        this.i = string8;
        this.j = n3;
        this.k = collection;
    }
}

