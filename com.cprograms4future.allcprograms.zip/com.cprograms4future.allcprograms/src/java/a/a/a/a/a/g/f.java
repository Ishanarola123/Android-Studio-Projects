/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a.a.a.a.a.g;

public class f {
    public final String a;
    public final int b;

    public f(String string, int n2) {
        this.a = string;
        this.b = n2;
    }
}

