/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a.a.a.a.a.g;

public class b {
    public final String a;
    public final int b;
    public final int c;
    public final int d;
    public final int e;
    public final boolean f;
    public final boolean g;
    public final boolean h;
    public final int i;

    public b(String string, int n2, int n3, int n4, int n5, boolean bl, boolean bl2, int n6, boolean bl3) {
        this.a = string;
        this.b = n2;
        this.c = n3;
        this.d = n4;
        this.e = n5;
        this.f = bl;
        this.g = bl2;
        this.i = n6;
        this.h = bl3;
    }
}

