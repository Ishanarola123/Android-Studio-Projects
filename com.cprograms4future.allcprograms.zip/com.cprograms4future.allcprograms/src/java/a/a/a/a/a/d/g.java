/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package a.a.a.a.a.d;

import java.io.File;
import java.io.IOException;
import java.util.List;

public interface g {
    public int a();

    public List<File> a(int var1);

    public void a(String var1) throws IOException;

    public void a(List<File> var1);

    public void a(byte[] var1) throws IOException;

    public boolean a(int var1, int var2);

    public boolean b();

    public List<File> c();
}

