/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a.a.a.a.a.g;

import a.a.a.a.a.g.b;
import a.a.a.a.a.g.e;
import a.a.a.a.a.g.f;
import a.a.a.a.a.g.m;
import a.a.a.a.a.g.o;
import a.a.a.a.a.g.p;

public class t {
    public final e a;
    public final p b;
    public final o c;
    public final m d;
    public final b e;
    public final f f;
    public final long g;
    public final int h;
    public final int i;

    public t(long l2, e e2, p p2, o o2, m m2, b b2, f f2, int n2, int n3) {
        this.g = l2;
        this.a = e2;
        this.b = p2;
        this.c = o2;
        this.d = m2;
        this.h = n2;
        this.i = n3;
        this.e = b2;
        this.f = f2;
    }

    public boolean a(long l2) {
        return this.g < l2;
    }
}

