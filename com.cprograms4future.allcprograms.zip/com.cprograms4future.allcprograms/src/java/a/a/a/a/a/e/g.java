/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.InputStream
 *  java.lang.Object
 *  java.lang.String
 */
package a.a.a.a.a.e;

import java.io.InputStream;

public interface g {
    public InputStream a();

    public String b();

    public String[] c();

    public long d();
}

