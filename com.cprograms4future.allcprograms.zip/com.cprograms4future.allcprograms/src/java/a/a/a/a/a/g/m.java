/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a.a.a.a.a.g;

public class m {
    public final boolean a;
    public final boolean b;
    public final boolean c;
    public final boolean d;

    public m(boolean bl, boolean bl2, boolean bl3, boolean bl4) {
        this.a = bl;
        this.b = bl2;
        this.c = bl3;
        this.d = bl4;
    }
}

