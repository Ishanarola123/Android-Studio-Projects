/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  java.lang.Object
 */
package a.a.a.a.a.f;

import android.content.SharedPreferences;

public interface b {
    public SharedPreferences a();

    public boolean a(SharedPreferences.Editor var1);

    public SharedPreferences.Editor b();
}

