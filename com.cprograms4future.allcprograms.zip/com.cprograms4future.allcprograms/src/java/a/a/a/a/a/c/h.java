/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Comparable
 *  java.lang.Object
 */
package a.a.a.a.a.c;

import a.a.a.a.a.c.e;

public interface h<T>
extends Comparable<T> {
    public e b();
}

