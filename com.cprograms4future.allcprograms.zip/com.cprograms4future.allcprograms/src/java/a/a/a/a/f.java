/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a.a.a.a.f$a
 *  java.lang.Exception
 *  java.lang.Object
 */
package a.a.a.a;

import a.a.a.a.f;

public interface f<T> {
    public static final f d;

    static {
        d = new /* Unavailable Anonymous Inner Class!! */;
    }

    public void a(Exception var1);

    public void a(T var1);

}

