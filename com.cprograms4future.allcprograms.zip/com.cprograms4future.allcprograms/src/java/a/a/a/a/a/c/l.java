/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.RuntimeException
 *  java.lang.String
 */
package a.a.a.a.a.c;

public class l
extends RuntimeException {
    public l() {
    }

    public l(String string) {
        super(string);
    }
}

