/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package a.a.a.a.a.e;

import a.a.a.a.a.e.c;
import a.a.a.a.a.e.d;
import java.util.Map;

public interface e {
    public d a(c var1, String var2, Map<String, String> var3);
}

