/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package a.a.a.a;

public interface l {
    public void a(int var1, String var2, String var3);

    public void a(String var1, String var2);

    public void a(String var1, String var2, Throwable var3);

    public boolean a(String var1, int var2);

    public void b(String var1, String var2);

    public void c(String var1, String var2);

    public void c(String var1, String var2, Throwable var3);

    public void d(String var1, String var2);

    public void d(String var1, String var2, Throwable var3);
}

