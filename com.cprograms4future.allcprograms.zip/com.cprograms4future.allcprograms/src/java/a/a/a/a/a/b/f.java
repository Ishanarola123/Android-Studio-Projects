/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a.a.a.a.a.b;

import a.a.a.a.a.b.b;

public interface f {
    public b a();
}

