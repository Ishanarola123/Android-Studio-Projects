/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a.a.a.a.a.d;

import a.a.a.a.a.d.i;
import a.a.a.a.a.d.k;

public class a<T>
implements i<T> {
    @Override
    public k a() {
        return null;
    }

    @Override
    public void a(T t) {
    }

    @Override
    public void b() {
    }

    @Override
    public void c() {
    }

    @Override
    public boolean d() {
        return false;
    }
}

