/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.Collection
 */
package a.a.a.a;

import a.a.a.a.i;
import java.util.Collection;

public interface j {
    public Collection<? extends i> c();
}

