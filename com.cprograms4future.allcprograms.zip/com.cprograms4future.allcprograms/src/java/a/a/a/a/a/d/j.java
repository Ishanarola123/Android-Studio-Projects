/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 */
package a.a.a.a.a.d;

import java.io.IOException;

public interface j {
    public void c();

    public boolean d() throws IOException;
}

