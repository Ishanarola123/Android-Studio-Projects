/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Throwable
 */
package a.a.a.a.a.c;

public interface k {
    public void a(Throwable var1);

    public void b(boolean var1);

    public boolean f();
}

