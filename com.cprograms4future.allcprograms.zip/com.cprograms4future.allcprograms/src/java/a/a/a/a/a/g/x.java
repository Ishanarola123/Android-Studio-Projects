/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  org.json.JSONObject
 */
package a.a.a.a.a.g;

import a.a.a.a.a.g.w;
import org.json.JSONObject;

public interface x {
    public JSONObject a(w var1);
}

