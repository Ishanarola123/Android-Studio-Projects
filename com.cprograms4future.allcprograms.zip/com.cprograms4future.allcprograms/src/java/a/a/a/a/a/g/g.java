/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  org.json.JSONObject
 */
package a.a.a.a.a.g;

import org.json.JSONObject;

public interface g {
    public JSONObject a();

    public void a(long var1, JSONObject var3);
}

