/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 */
package a.a.a.a.a.g;

import a.a.a.a.a.e.c;
import a.a.a.a.a.e.e;
import a.a.a.a.a.g.a;
import a.a.a.a.a.g.d;
import a.a.a.a.i;

public class h
extends a {
    public h(i i2, String string, String string2, e e2) {
        super(i2, string, string2, e2, c.b);
    }
}

