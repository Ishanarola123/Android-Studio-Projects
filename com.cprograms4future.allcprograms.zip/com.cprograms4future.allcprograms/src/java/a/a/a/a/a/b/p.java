/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a.a.a.a.a.b;

public class p {
    public static int a(int n2) {
        if (n2 >= 200 && n2 <= 299) {
            return 0;
        }
        if (n2 >= 300 && n2 <= 399) {
            return 1;
        }
        if (n2 >= 400 && n2 <= 499) {
            return 0;
        }
        if (n2 >= 500) {
            // empty if block
        }
        return 1;
    }
}

