/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a.a.a.a.a.g;

class c {
    public final String a;
    public final int b;
    public final int c;

    public c(String string, int n2, int n3) {
        this.a = string;
        this.b = n2;
        this.c = n3;
    }
}

