/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Exception
 *  java.lang.Object
 */
package a.a.a.a.a.a;

import a.a.a.a.a.a.d;
import android.content.Context;

public interface c<T> {
    public T a(Context var1, d<T> var2) throws Exception;
}

