/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a.a.a.a.a.b;

public interface j {
    public long a();
}

