/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a.a.a.a.a.g;

import a.a.a.a.a.g.c;

public class e {
    public final String a;
    public final String b;
    public final String c;
    public final String d;
    public final boolean e;
    public final c f;

    public e(String string, String string2, String string3, String string4, boolean bl, c c2) {
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = string4;
        this.e = bl;
        this.f = c2;
    }
}

