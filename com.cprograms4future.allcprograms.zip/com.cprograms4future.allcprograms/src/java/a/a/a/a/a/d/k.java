/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Object
 *  java.util.List
 */
package a.a.a.a.a.d;

import java.io.File;
import java.util.List;

public interface k {
    public boolean a(List<File> var1);
}

