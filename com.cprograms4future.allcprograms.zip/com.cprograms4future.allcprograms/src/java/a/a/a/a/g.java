/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.RuntimeException
 *  java.lang.String
 */
package a.a.a.a;

public class g
extends RuntimeException {
    public g(String string) {
        super(string);
    }
}

