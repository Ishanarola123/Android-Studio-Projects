/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c.c
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 */
package c;

import c.c;
import c.f;
import c.q;
import c.r;
import java.io.IOException;

public interface d
extends q {
    public long a(r var1) throws IOException;

    public d b(f var1) throws IOException;

    public d b(String var1) throws IOException;

    public c c();

    public d c(byte[] var1) throws IOException;

    public d c(byte[] var1, int var2, int var3) throws IOException;

    public d f() throws IOException;

    public d f(int var1) throws IOException;

    public d g(int var1) throws IOException;

    public d h(int var1) throws IOException;

    public d j(long var1) throws IOException;

    public d k(long var1) throws IOException;

    public d u() throws IOException;
}

