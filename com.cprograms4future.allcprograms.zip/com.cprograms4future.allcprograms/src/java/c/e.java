/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c.c
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Object
 *  java.lang.String
 */
package c;

import c.c;
import c.f;
import c.q;
import c.r;
import java.io.IOException;
import java.io.InputStream;

public interface e
extends r {
    public long a(byte var1) throws IOException;

    public long a(q var1) throws IOException;

    public void a(long var1) throws IOException;

    public c c();

    public f c(long var1) throws IOException;

    public byte[] f(long var1) throws IOException;

    public void g(long var1) throws IOException;

    public boolean g() throws IOException;

    public InputStream h();

    public byte j() throws IOException;

    public short k() throws IOException;

    public int l() throws IOException;

    public short m() throws IOException;

    public int n() throws IOException;

    public long o() throws IOException;

    public String r() throws IOException;
}

