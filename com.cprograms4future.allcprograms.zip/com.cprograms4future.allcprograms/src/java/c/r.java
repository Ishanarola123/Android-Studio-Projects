/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c.c
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Object
 */
package c;

import c.c;
import c.s;
import java.io.Closeable;
import java.io.IOException;

public interface r
extends Closeable {
    public long a(c var1, long var2) throws IOException;

    public s a();

    public void close() throws IOException;
}

