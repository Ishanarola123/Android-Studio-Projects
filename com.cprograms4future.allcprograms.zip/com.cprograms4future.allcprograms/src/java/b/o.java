/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b.o$1
 *  java.lang.Object
 *  java.lang.String
 *  java.net.InetAddress
 *  java.net.UnknownHostException
 *  java.util.List
 */
package b;

import b.o;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;

public interface o {
    public static final o a = new 1();

    public List<InetAddress> a(String var1) throws UnknownHostException;
}

