/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 */
package b;

import b.ab;
import b.e;
import java.io.IOException;

public interface f {
    public void a(e var1, ab var2) throws IOException;

    public void a(e var1, IOException var2);
}

