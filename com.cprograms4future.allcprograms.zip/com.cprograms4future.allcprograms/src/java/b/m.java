/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b.m$1
 *  java.lang.Object
 *  java.util.List
 */
package b;

import b.l;
import b.m;
import b.s;
import java.util.List;

public interface m {
    public static final m a = new 1();

    public List<l> a(s var1);

    public void a(s var1, List<l> var2);
}

