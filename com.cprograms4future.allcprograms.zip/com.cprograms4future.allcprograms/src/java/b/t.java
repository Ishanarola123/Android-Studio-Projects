/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 */
package b;

import b.ab;
import b.z;
import java.io.IOException;

public interface t {
    public ab a(a var1) throws IOException;

    public static interface a {
        public ab a(z var1) throws IOException;

        public z a();
    }

}

