/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 */
package b;

import b.ab;
import b.f;
import b.z;
import java.io.IOException;

public interface e {
    public ab a() throws IOException;

    public void a(f var1);

    public void b();

    public static interface a {
        public e a(z var1);
    }

}

