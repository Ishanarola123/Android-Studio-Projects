/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package b;

import b.ad;

public interface i {
    public ad a();
}

