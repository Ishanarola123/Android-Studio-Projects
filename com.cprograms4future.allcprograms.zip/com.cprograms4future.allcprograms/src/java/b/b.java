/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b.b$1
 *  java.io.IOException
 *  java.lang.Object
 */
package b;

import b.ab;
import b.ad;
import b.b;
import b.z;
import java.io.IOException;

public interface b {
    public static final b b = new 1();

    public z a(ad var1, ab var2) throws IOException;
}

