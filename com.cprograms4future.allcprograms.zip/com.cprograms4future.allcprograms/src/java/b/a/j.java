/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package b.a;

public final class j {
    public static String a() {
        return "okhttp/3.2.0";
    }
}

