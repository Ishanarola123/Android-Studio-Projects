/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 */
package b.a;

import b.a.b.a;
import b.a.b.b;
import b.ab;
import b.z;
import java.io.IOException;

public interface d {
    public a a(ab var1) throws IOException;

    public ab a(z var1) throws IOException;

    public void a();

    public void a(b var1);

    public void a(ab var1, ab var2) throws IOException;

    public void b(z var1) throws IOException;
}

