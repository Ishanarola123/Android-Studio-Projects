/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b.a.c.a$1
 *  java.io.File
 *  java.io.IOException
 *  java.lang.Object
 */
package b.a.c;

import b.a.c.a;
import java.io.File;
import java.io.IOException;

public interface a {
    public static final a a = new 1();

    public void a(File var1) throws IOException;

    public void a(File var1, File var2) throws IOException;

    public boolean b(File var1);

    public long c(File var1);
}

