/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c.d
 *  c.e
 *  java.lang.Object
 */
package b.a.a;

import b.a.a.b;
import b.a.a.c;
import c.d;
import c.e;

public interface p {
    public b a(e var1, boolean var2);

    public c a(d var1, boolean var2);
}

