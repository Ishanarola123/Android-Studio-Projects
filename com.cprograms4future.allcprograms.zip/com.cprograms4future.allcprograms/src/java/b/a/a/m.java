/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b.a.a.m$1
 *  c.e
 *  java.io.IOException
 *  java.lang.Object
 *  java.util.List
 */
package b.a.a;

import b.a.a.a;
import b.a.a.f;
import b.a.a.m;
import c.e;
import java.io.IOException;
import java.util.List;

public interface m {
    public static final m a = new 1();

    public void a(int var1, a var2);

    public boolean a(int var1, e var2, int var3, boolean var4) throws IOException;

    public boolean a(int var1, List<f> var2);

    public boolean a(int var1, List<f> var2, boolean var3);
}

