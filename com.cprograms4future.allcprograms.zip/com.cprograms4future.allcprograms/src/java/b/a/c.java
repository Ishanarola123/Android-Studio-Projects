/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b.a.c.b
 *  b.w
 *  java.lang.Object
 *  java.lang.String
 *  java.util.logging.Logger
 *  javax.net.ssl.SSLSocket
 */
package b.a;

import b.a;
import b.a.b.r;
import b.a.c.b;
import b.a.d;
import b.a.h;
import b.j;
import b.k;
import b.r;
import b.w;
import java.util.logging.Logger;
import javax.net.ssl.SSLSocket;

public abstract class c {
    public static final Logger a = Logger.getLogger((String)w.class.getName());
    public static c b;

    public abstract b a(j var1, a var2, r var3);

    public abstract d a(w var1);

    public abstract h a(j var1);

    public abstract void a(k var1, SSLSocket var2, boolean var3);

    public abstract void a(r.a var1, String var2);

    public abstract boolean a(j var1, b var2);

    public abstract void b(j var1, b var2);
}

