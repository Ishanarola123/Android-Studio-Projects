/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 */
package b.a.b;

import c.q;
import java.io.IOException;

public interface a {
    public q a() throws IOException;

    public void b();
}

