/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b.a.b.n
 *  java.io.IOException
 *  java.lang.Object
 */
package b.a.b;

import b.a.b.g;
import b.a.b.n;
import b.ab;
import b.ac;
import b.z;
import c.q;
import java.io.IOException;

public interface i {
    public ac a(ab var1) throws IOException;

    public q a(z var1, long var2) throws IOException;

    public void a();

    public void a(g var1);

    public void a(n var1) throws IOException;

    public void a(z var1) throws IOException;

    public ab.a b() throws IOException;

    public void c() throws IOException;
}

