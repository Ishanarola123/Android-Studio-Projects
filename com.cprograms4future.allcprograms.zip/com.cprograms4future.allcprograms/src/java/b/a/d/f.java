/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.security.cert.X509Certificate
 */
package b.a.d;

import java.security.cert.X509Certificate;

public interface f {
    public X509Certificate a(X509Certificate var1);
}

