# EasyTutoNotes

Simple notes app using Realm Database
- Add notes
- List notes
- Delete notes

Watch full tutorial :
https://youtu.be/or_pH92l-IQ
