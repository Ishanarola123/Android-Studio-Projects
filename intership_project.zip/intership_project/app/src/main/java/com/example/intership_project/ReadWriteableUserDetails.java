package com.example.intership_project;

public class ReadWriteableUserDetails {
    public String  username,phone_number,email,password;

    public ReadWriteableUserDetails(String username, String phone_number, String email, String password) {
        this.username = username;
        this.phone_number = phone_number;
        this.email = email;
        this.password = password;
    }
}
