package com.example.intership_project.recviewcat;

public class Model {
    private String categoriesheader;
    private int imgname;


    public String getCategoriesheader() {
        return categoriesheader;
    }

    public void setCategoriesheader(String categoriesheader) {
        this.categoriesheader = categoriesheader;
    }

    public int getImgname() {
        return imgname;
    }

    public void setImgname(int imgname) {
        this.imgname = imgname;
    }
}
