package com.example.intership_project.recviewpopular.Dynamic;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.example.intership_project.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

public class myadapter extends FirebaseRecyclerAdapter<model,myviewholder> {
    public myadapter(@NonNull FirebaseRecyclerOptions<model> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull myviewholder myviewholder, int i, @NonNull model model) {
        myviewholder.itemname.setText(model.getFoodname() + "");
        myviewholder.itemprice.setText((int) model.getFoodPrice() + "");
        Glide.with(myviewholder.imageView.getContext()).load(model.getImageUrl()).into(myviewholder.imageView);

    }

    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.singlerow_popular_categories,parent,false);
        return new myviewholder(view);
    }
}
