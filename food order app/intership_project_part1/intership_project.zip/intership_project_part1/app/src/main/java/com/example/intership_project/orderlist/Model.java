package com.example.intership_project.orderlist;

public class Model {

String itemname;
double price;
int orderquantity;

    public Model() {
    }

    public Model(String itemname, double price, int orderquantity) {
        this.itemname = itemname;
        this.price = price;
        this.orderquantity = orderquantity;
    }



    public String getItemname() {
        return itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getOrderquantity() {
        return orderquantity;
    }

    public void setOrderquantity(int orderquantity) {
        this.orderquantity = orderquantity;
    }
}
