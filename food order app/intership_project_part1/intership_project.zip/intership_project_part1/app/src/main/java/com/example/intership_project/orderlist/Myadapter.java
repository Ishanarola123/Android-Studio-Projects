package com.example.intership_project.orderlist;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.intership_project.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

public class Myadapter extends FirebaseRecyclerAdapter<Model,Myadapter.myviewholder> {

    public Myadapter(@NonNull FirebaseRecyclerOptions<Model> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull myviewholder holder, int position, @NonNull Model model) {
//        holder.itemimage.setImageResource(R.drawable.cat_1);
        holder.textviewitemname.setText(model.getItemname() + "");
        holder.textviewprice.setText("$ "+ model.getPrice() );
        holder.textvieworderquantity.setText("order : " + model.getOrderquantity());;
    }


    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
//        View view = inflater.inflate(R.layout.singlerow_categories, parent, false);
        View view=LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_order_list,parent,false);
        return new myviewholder(view);
    }

    public static class myviewholder extends  RecyclerView.ViewHolder{
        ImageView itemimage;
        TextView textviewitemname;
        TextView textvieworderquantity, textviewprice;

        public myviewholder(@NonNull View itemView) {
            super(itemView);
            itemimage=itemView.findViewById(R.id.itemimage);
            textviewitemname=itemView.findViewById(R.id.itemname_orderlist);
            textvieworderquantity=itemView.findViewById(R.id.orderquantity);
            textviewprice=itemView.findViewById(R.id.price);

        }
    }

}
