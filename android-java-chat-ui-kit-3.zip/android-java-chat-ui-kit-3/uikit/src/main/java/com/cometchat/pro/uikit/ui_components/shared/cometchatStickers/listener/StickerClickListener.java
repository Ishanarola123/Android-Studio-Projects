package com.cometchat.pro.uikit.ui_components.shared.cometchatStickers.listener;

import com.cometchat.pro.uikit.ui_components.shared.cometchatStickers.model.Sticker;

public interface StickerClickListener {
    void onClickListener(Sticker sticker);
}
