package com.example.messageapp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;

import com.example.messageapp.databinding.ActivityMain3Binding;
import com.example.messageapp.utilities.constants;
import com.example.messageapp.utilities.preferencemanager;

public class MainActivity3 extends AppCompatActivity {
    private ActivityMain3Binding binding;
    private preferencemanager  preferencemanager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(binding.getRoot());
        preferencemanager=new preferencemanager(getApplicationContext());
        loaduserdetails();

    }
private void loaduserdetails(){
        binding.textname.setText(preferencemanager.getString(constants.KEY_NAME));
        byte[] bytes= Base64.decode(preferencemanager.getString(constants.KEY_IMAGE),Base64.DEFAULT);
    Bitmap bitmap= BitmapFactory.decodeByteArray(bytes,0,bytes.length);
    binding.imageprofile.setImageBitmap(bitmap);

}

}