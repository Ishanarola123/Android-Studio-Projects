package com.example.messageapp.models;

import java.io.Serializable;

public class User implements Serializable {
    public  String name,image,email,token;



}
