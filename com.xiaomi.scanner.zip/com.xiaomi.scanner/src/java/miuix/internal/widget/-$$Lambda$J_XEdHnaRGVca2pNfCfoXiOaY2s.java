/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.widget.PopupWindow
 *  android.widget.PopupWindow$OnDismissListener
 *  java.lang.Object
 *  miuix.internal.widget.PopupMenuWindow
 */
package miuix.internal.widget;

import android.widget.PopupWindow;
import miuix.internal.widget.PopupMenuWindow;

public final class -$$Lambda$J_XEdHnaRGVca2pNfCfoXiOaY2s
implements PopupWindow.OnDismissListener {
    private final /* synthetic */ PopupMenuWindow f$0;

    public /* synthetic */ -$$Lambda$J_XEdHnaRGVca2pNfCfoXiOaY2s(PopupMenuWindow popupMenuWindow) {
        this.f$0 = popupMenuWindow;
    }

    public final void onDismiss() {
        this.f$0.onDismiss();
    }
}

