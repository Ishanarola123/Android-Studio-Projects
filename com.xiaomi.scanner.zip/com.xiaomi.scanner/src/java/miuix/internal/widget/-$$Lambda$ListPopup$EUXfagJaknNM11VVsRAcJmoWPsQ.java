/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.widget.PopupWindow
 *  android.widget.PopupWindow$OnDismissListener
 *  java.lang.Object
 */
package miuix.internal.widget;

import android.widget.PopupWindow;
import miuix.internal.widget.ListPopup;

public final class -$$Lambda$ListPopup$EUXfagJaknNM11VVsRAcJmoWPsQ
implements PopupWindow.OnDismissListener {
    private final /* synthetic */ ListPopup f$0;

    public /* synthetic */ -$$Lambda$ListPopup$EUXfagJaknNM11VVsRAcJmoWPsQ(ListPopup listPopup) {
        this.f$0 = listPopup;
    }

    public final void onDismiss() {
        this.f$0.lambda$new$1$ListPopup();
    }
}

