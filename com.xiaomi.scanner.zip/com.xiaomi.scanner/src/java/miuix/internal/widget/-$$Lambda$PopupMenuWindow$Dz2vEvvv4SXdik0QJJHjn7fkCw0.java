/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  java.lang.Object
 *  miuix.internal.widget.PopupMenuWindow
 */
package miuix.internal.widget;

import android.view.View;
import android.widget.AdapterView;
import miuix.internal.widget.PopupMenuWindow;

public final class -$$Lambda$PopupMenuWindow$Dz2vEvvv4SXdik0QJJHjn7fkCw0
implements AdapterView.OnItemClickListener {
    private final /* synthetic */ PopupMenuWindow f$0;

    public /* synthetic */ -$$Lambda$PopupMenuWindow$Dz2vEvvv4SXdik0QJJHjn7fkCw0(PopupMenuWindow popupMenuWindow) {
        this.f$0 = popupMenuWindow;
    }

    public final void onItemClick(AdapterView adapterView, View view, int n, long l) {
        this.f$0.lambda$new$1$PopupMenuWindow(adapterView, view, n, l);
    }
}

