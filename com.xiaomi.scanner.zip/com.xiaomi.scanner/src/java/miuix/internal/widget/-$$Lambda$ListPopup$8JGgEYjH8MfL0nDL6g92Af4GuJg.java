/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  java.lang.Object
 */
package miuix.internal.widget;

import android.view.View;
import miuix.internal.widget.ListPopup;

public final class -$$Lambda$ListPopup$8JGgEYjH8MfL0nDL6g92Af4GuJg
implements View.OnClickListener {
    private final /* synthetic */ ListPopup f$0;

    public /* synthetic */ -$$Lambda$ListPopup$8JGgEYjH8MfL0nDL6g92Af4GuJg(ListPopup listPopup) {
        this.f$0 = listPopup;
    }

    public final void onClick(View view) {
        this.f$0.lambda$new$0$ListPopup(view);
    }
}

