/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package miuix.recyclerview.animator;

public final class R {
    private R() {
    }

    public static final class attr {
        public static final int alpha = 2130968680;
        public static final int fastScrollEnabled = 2130968985;
        public static final int fastScrollHorizontalThumbDrawable = 2130968986;
        public static final int fastScrollHorizontalTrackDrawable = 2130968987;
        public static final int fastScrollVerticalThumbDrawable = 2130968988;
        public static final int fastScrollVerticalTrackDrawable = 2130968989;
        public static final int font = 2130968997;
        public static final int fontProviderAuthority = 2130968999;
        public static final int fontProviderCerts = 2130969000;
        public static final int fontProviderFetchStrategy = 2130969001;
        public static final int fontProviderFetchTimeout = 2130969002;
        public static final int fontProviderPackage = 2130969003;
        public static final int fontProviderQuery = 2130969004;
        public static final int fontStyle = 2130969005;
        public static final int fontVariationSettings = 2130969006;
        public static final int fontWeight = 2130969007;
        public static final int layoutManager = 2130969079;
        public static final int recyclerViewStyle = 2130969305;
        public static final int reverseLayout = 2130969307;
        public static final int spanCount = 2130969354;
        public static final int stackFromEnd = 2130969367;
        public static final int ttcIndex = 2130969515;

        private attr() {
        }
    }

    public static final class color {
        public static final int miuix_folme_color_touch_tint = 2131100200;
        public static final int miuix_folme_color_touch_tint_dark = 2131100201;
        public static final int notification_action_color_filter = 2131100299;
        public static final int notification_icon_bg_color = 2131100300;
        public static final int ripple_material_light = 2131100312;
        public static final int secondary_text_default_material_light = 2131100314;

        private color() {
        }
    }

    public static final class dimen {
        public static final int compat_button_inset_horizontal_material = 2131165271;
        public static final int compat_button_inset_vertical_material = 2131165272;
        public static final int compat_button_padding_horizontal_material = 2131165273;
        public static final int compat_button_padding_vertical_material = 2131165274;
        public static final int compat_control_corner_material = 2131165275;
        public static final int compat_notification_large_icon_max_height = 2131165276;
        public static final int compat_notification_large_icon_max_width = 2131165277;
        public static final int fastscroll_default_thickness = 2131165342;
        public static final int fastscroll_margin = 2131165343;
        public static final int fastscroll_minimum_range = 2131165344;
        public static final int item_touch_helper_max_drag_scroll_per_frame = 2131165357;
        public static final int item_touch_helper_swipe_escape_max_velocity = 2131165358;
        public static final int item_touch_helper_swipe_escape_velocity = 2131165359;
        public static final int notification_action_icon_size = 2131165821;
        public static final int notification_action_text_size = 2131165822;
        public static final int notification_big_circle_margin = 2131165823;
        public static final int notification_content_margin_start = 2131165824;
        public static final int notification_large_icon_height = 2131165825;
        public static final int notification_large_icon_width = 2131165826;
        public static final int notification_main_column_padding_top = 2131165827;
        public static final int notification_media_narrow_margin = 2131165828;
        public static final int notification_right_icon_size = 2131165829;
        public static final int notification_right_side_padding_top = 2131165830;
        public static final int notification_small_icon_background_padding = 2131165831;
        public static final int notification_small_icon_size_as_large = 2131165832;
        public static final int notification_subtext_size = 2131165833;
        public static final int notification_top_pad = 2131165834;
        public static final int notification_top_pad_large_text = 2131165835;

        private dimen() {
        }
    }

    public static final class drawable {
        public static final int notification_action_background = 2131231699;
        public static final int notification_bg = 2131231700;
        public static final int notification_bg_low = 2131231701;
        public static final int notification_bg_low_normal = 2131231702;
        public static final int notification_bg_low_pressed = 2131231703;
        public static final int notification_bg_normal = 2131231704;
        public static final int notification_bg_normal_pressed = 2131231705;
        public static final int notification_icon_background = 2131231706;
        public static final int notification_template_icon_bg = 2131231707;
        public static final int notification_template_icon_low_bg = 2131231708;
        public static final int notification_tile_bg = 2131231709;
        public static final int notify_panel_notification_icon_bg = 2131231710;

        private drawable() {
        }
    }

    public static final class id {
        public static final int accessibility_action_clickable_span = 2131361800;
        public static final int accessibility_custom_action_0 = 2131361801;
        public static final int accessibility_custom_action_1 = 2131361802;
        public static final int accessibility_custom_action_10 = 2131361803;
        public static final int accessibility_custom_action_11 = 2131361804;
        public static final int accessibility_custom_action_12 = 2131361805;
        public static final int accessibility_custom_action_13 = 2131361806;
        public static final int accessibility_custom_action_14 = 2131361807;
        public static final int accessibility_custom_action_15 = 2131361808;
        public static final int accessibility_custom_action_16 = 2131361809;
        public static final int accessibility_custom_action_17 = 2131361810;
        public static final int accessibility_custom_action_18 = 2131361811;
        public static final int accessibility_custom_action_19 = 2131361812;
        public static final int accessibility_custom_action_2 = 2131361813;
        public static final int accessibility_custom_action_20 = 2131361814;
        public static final int accessibility_custom_action_21 = 2131361815;
        public static final int accessibility_custom_action_22 = 2131361816;
        public static final int accessibility_custom_action_23 = 2131361817;
        public static final int accessibility_custom_action_24 = 2131361818;
        public static final int accessibility_custom_action_25 = 2131361819;
        public static final int accessibility_custom_action_26 = 2131361820;
        public static final int accessibility_custom_action_27 = 2131361821;
        public static final int accessibility_custom_action_28 = 2131361822;
        public static final int accessibility_custom_action_29 = 2131361823;
        public static final int accessibility_custom_action_3 = 2131361824;
        public static final int accessibility_custom_action_30 = 2131361825;
        public static final int accessibility_custom_action_31 = 2131361826;
        public static final int accessibility_custom_action_4 = 2131361827;
        public static final int accessibility_custom_action_5 = 2131361828;
        public static final int accessibility_custom_action_6 = 2131361829;
        public static final int accessibility_custom_action_7 = 2131361830;
        public static final int accessibility_custom_action_8 = 2131361831;
        public static final int accessibility_custom_action_9 = 2131361832;
        public static final int action_container = 2131361846;
        public static final int action_divider = 2131361849;
        public static final int action_image = 2131361850;
        public static final int action_text = 2131361858;
        public static final int actions = 2131361859;
        public static final int async = 2131361873;
        public static final int blocking = 2131361877;
        public static final int chronometer = 2131361909;
        public static final int dialog_button = 2131361947;
        public static final int forever = 2131361986;
        public static final int icon = 2131362001;
        public static final int icon_group = 2131362003;
        public static final int info = 2131362010;
        public static final int italic = 2131362013;
        public static final int item_touch_helper_previous_elevation = 2131362014;
        public static final int line1 = 2131362023;
        public static final int line3 = 2131362024;
        public static final int miuix_animation_tag_foreground_color = 2131362039;
        public static final int miuix_animation_tag_init_layout = 2131362040;
        public static final int miuix_animation_tag_is_dragging = 2131362041;
        public static final int miuix_animation_tag_listview_pos = 2131362042;
        public static final int miuix_animation_tag_set_height = 2131362043;
        public static final int miuix_animation_tag_set_width = 2131362044;
        public static final int miuix_animation_tag_touch_listener = 2131362045;
        public static final int normal = 2131362062;
        public static final int notification_background = 2131362064;
        public static final int notification_main_column = 2131362065;
        public static final int notification_main_column_container = 2131362066;
        public static final int right_icon = 2131362102;
        public static final int right_side = 2131362103;
        public static final int tag_accessibility_actions = 2131362178;
        public static final int tag_accessibility_clickable_spans = 2131362179;
        public static final int tag_accessibility_heading = 2131362180;
        public static final int tag_accessibility_pane_title = 2131362181;
        public static final int tag_screen_reader_focusable = 2131362184;
        public static final int tag_transition_group = 2131362187;
        public static final int tag_unhandled_key_event_manager = 2131362188;
        public static final int tag_unhandled_key_listeners = 2131362189;
        public static final int text = 2131362190;
        public static final int text2 = 2131362191;
        public static final int time = 2131362201;
        public static final int title = 2131362204;

        private id() {
        }
    }

    public static final class integer {
        public static final int status_bar_notification_info_maxnum = 2131427371;

        private integer() {
        }
    }

    public static final class layout {
        public static final int custom_dialog = 2131558436;
        public static final int notification_action = 2131558563;
        public static final int notification_action_tombstone = 2131558564;
        public static final int notification_template_custom_big = 2131558565;
        public static final int notification_template_icon_group = 2131558566;
        public static final int notification_template_part_chronometer = 2131558567;
        public static final int notification_template_part_time = 2131558568;

        private layout() {
        }
    }

    public static final class string {
        public static final int status_bar_notification_info_overflow = 2131755460;

        private string() {
        }
    }

    public static final class style {
        public static final int TextAppearance_Compat_Notification = 2131820958;
        public static final int TextAppearance_Compat_Notification_Info = 2131820959;
        public static final int TextAppearance_Compat_Notification_Line2 = 2131820960;
        public static final int TextAppearance_Compat_Notification_Time = 2131820961;
        public static final int TextAppearance_Compat_Notification_Title = 2131820962;
        public static final int Widget_Compat_NotificationActionContainer = 2131821268;
        public static final int Widget_Compat_NotificationActionText = 2131821269;

        private style() {
        }
    }

    public static final class styleable {
        public static final int[] ColorStateListItem = new int[]{16843173, 16843551, 2130968680};
        public static final int ColorStateListItem_alpha = 2;
        public static final int ColorStateListItem_android_alpha = 1;
        public static final int ColorStateListItem_android_color = 0;
        public static final int[] FontFamily = new int[]{2130968999, 2130969000, 2130969001, 2130969002, 2130969003, 2130969004};
        public static final int[] FontFamilyFont = new int[]{16844082, 16844083, 16844095, 16844143, 16844144, 2130968997, 2130969005, 2130969006, 2130969007, 2130969515};
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontVariationSettings = 4;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_android_ttcIndex = 3;
        public static final int FontFamilyFont_font = 5;
        public static final int FontFamilyFont_fontStyle = 6;
        public static final int FontFamilyFont_fontVariationSettings = 7;
        public static final int FontFamilyFont_fontWeight = 8;
        public static final int FontFamilyFont_ttcIndex = 9;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
        public static final int[] GradientColor = new int[]{16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static final int[] GradientColorItem = new int[]{16843173, 16844052};
        public static final int GradientColorItem_android_color = 0;
        public static final int GradientColorItem_android_offset = 1;
        public static final int GradientColor_android_centerColor = 7;
        public static final int GradientColor_android_centerX = 3;
        public static final int GradientColor_android_centerY = 4;
        public static final int GradientColor_android_endColor = 1;
        public static final int GradientColor_android_endX = 10;
        public static final int GradientColor_android_endY = 11;
        public static final int GradientColor_android_gradientRadius = 5;
        public static final int GradientColor_android_startColor = 0;
        public static final int GradientColor_android_startX = 8;
        public static final int GradientColor_android_startY = 9;
        public static final int GradientColor_android_tileMode = 6;
        public static final int GradientColor_android_type = 2;
        public static final int[] RecyclerView = new int[]{16842948, 16842987, 16842993, 2130968985, 2130968986, 2130968987, 2130968988, 2130968989, 2130969079, 2130969307, 2130969354, 2130969367};
        public static final int RecyclerView_android_clipToPadding = 1;
        public static final int RecyclerView_android_descendantFocusability = 2;
        public static final int RecyclerView_android_orientation = 0;
        public static final int RecyclerView_fastScrollEnabled = 3;
        public static final int RecyclerView_fastScrollHorizontalThumbDrawable = 4;
        public static final int RecyclerView_fastScrollHorizontalTrackDrawable = 5;
        public static final int RecyclerView_fastScrollVerticalThumbDrawable = 6;
        public static final int RecyclerView_fastScrollVerticalTrackDrawable = 7;
        public static final int RecyclerView_layoutManager = 8;
        public static final int RecyclerView_reverseLayout = 9;
        public static final int RecyclerView_spanCount = 10;
        public static final int RecyclerView_stackFromEnd = 11;

        private styleable() {
        }
    }

}

