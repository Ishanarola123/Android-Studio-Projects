/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package miuix.smooth;

public final class R {
    private R() {
    }

    public static final class attr {
        public static final int miuix_strokeColor = 2130969219;
        public static final int miuix_strokeWidth = 2130969220;

        private attr() {
        }
    }

    public static final class styleable {
        public static final int[] MiuixSmoothContainerDrawable = new int[]{16843176, 16843177, 16843178, 16843179, 16843180, 2130969219, 2130969220};
        public static final int MiuixSmoothContainerDrawable_android_bottomLeftRadius = 3;
        public static final int MiuixSmoothContainerDrawable_android_bottomRightRadius = 4;
        public static final int MiuixSmoothContainerDrawable_android_radius = 0;
        public static final int MiuixSmoothContainerDrawable_android_topLeftRadius = 1;
        public static final int MiuixSmoothContainerDrawable_android_topRightRadius = 2;
        public static final int MiuixSmoothContainerDrawable_miuix_strokeColor = 5;
        public static final int MiuixSmoothContainerDrawable_miuix_strokeWidth = 6;
        public static final int[] MiuixSmoothFrameLayout = new int[]{16843176, 16843177, 16843178, 16843179, 16843180, 2130969219, 2130969220};
        public static final int MiuixSmoothFrameLayout_android_bottomLeftRadius = 3;
        public static final int MiuixSmoothFrameLayout_android_bottomRightRadius = 4;
        public static final int MiuixSmoothFrameLayout_android_radius = 0;
        public static final int MiuixSmoothFrameLayout_android_topLeftRadius = 1;
        public static final int MiuixSmoothFrameLayout_android_topRightRadius = 2;
        public static final int MiuixSmoothFrameLayout_miuix_strokeColor = 5;
        public static final int MiuixSmoothFrameLayout_miuix_strokeWidth = 6;
        public static final int[] MiuixSmoothGradientDrawable = new int[]{2130969219, 2130969220};
        public static final int MiuixSmoothGradientDrawable_miuix_strokeColor = 0;
        public static final int MiuixSmoothGradientDrawable_miuix_strokeWidth = 1;

        private styleable() {
        }
    }

}

