/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.preference.Preference
 *  java.lang.Object
 */
package miuix.preference;

import androidx.preference.Preference;

interface OnPreferenceChangeInternalListener {
    public void notifyPreferenceChangeInternal(Preference var1);

    public boolean onPreferenceChangeInternal(Preference var1, Object var2);
}

