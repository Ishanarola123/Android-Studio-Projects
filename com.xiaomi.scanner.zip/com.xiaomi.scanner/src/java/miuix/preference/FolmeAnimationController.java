/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package miuix.preference;

public interface FolmeAnimationController {
    public boolean isTouchAnimationEnable();
}

