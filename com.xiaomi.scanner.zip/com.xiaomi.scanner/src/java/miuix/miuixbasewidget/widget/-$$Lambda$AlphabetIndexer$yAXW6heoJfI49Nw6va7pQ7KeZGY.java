/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package miuix.miuixbasewidget.widget;

import miuix.miuixbasewidget.widget.AlphabetIndexer;

public final class -$$Lambda$AlphabetIndexer$yAXW6heoJfI49Nw6va7pQ7KeZGY
implements Runnable {
    private final /* synthetic */ AlphabetIndexer f$0;

    public /* synthetic */ -$$Lambda$AlphabetIndexer$yAXW6heoJfI49Nw6va7pQ7KeZGY(AlphabetIndexer alphabetIndexer) {
        this.f$0 = alphabetIndexer;
    }

    public final void run() {
        AlphabetIndexer.lambda$yAXW6heoJfI49Nw6va7pQ7KeZGY(this.f$0);
    }
}

