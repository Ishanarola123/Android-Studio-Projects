/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.constraintlayout.widget.ConstraintLayout
 *  androidx.constraintlayout.widget.ConstraintLayout$LayoutParams
 *  java.lang.Object
 *  java.lang.Runnable
 *  miuix.miuixbasewidget.widget.FilterSortView
 */
package miuix.miuixbasewidget.widget;

import androidx.constraintlayout.widget.ConstraintLayout;
import miuix.miuixbasewidget.widget.FilterSortView;

public final class -$$Lambda$FilterSortView$x5mtRYhEO-Jj3EAe_QQwjvPf610
implements Runnable {
    private final /* synthetic */ FilterSortView f$0;
    private final /* synthetic */ ConstraintLayout.LayoutParams f$1;

    public /* synthetic */ -$$Lambda$FilterSortView$x5mtRYhEO-Jj3EAe_QQwjvPf610(FilterSortView filterSortView, ConstraintLayout.LayoutParams layoutParams) {
        this.f$0 = filterSortView;
        this.f$1 = layoutParams;
    }

    public final void run() {
        this.f$0.lambda$updateFiltered$0$FilterSortView(this.f$1);
    }
}

