/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package miuix.miuixbasewidget.widget;

import miuix.miuixbasewidget.widget.AlphabetIndexer;

public final class -$$Lambda$AlphabetIndexer$EFzw0Ci39-ROWdtLrZp19Uq0wo4
implements Runnable {
    private final /* synthetic */ AlphabetIndexer f$0;

    public /* synthetic */ -$$Lambda$AlphabetIndexer$EFzw0Ci39-ROWdtLrZp19Uq0wo4(AlphabetIndexer alphabetIndexer) {
        this.f$0 = alphabetIndexer;
    }

    public final void run() {
        this.f$0.lambda$init$0$AlphabetIndexer();
    }
}

