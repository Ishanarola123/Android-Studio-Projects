/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package miuix.overscroller.internal.dynamicanimation.animation;

interface Force {
    public float getAcceleration(float var1, float var2);

    public boolean isAtEquilibrium(float var1, float var2);
}

