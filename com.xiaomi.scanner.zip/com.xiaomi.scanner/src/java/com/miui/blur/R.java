/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.miui.blur;

public final class R {
    private R() {
    }

    public static final class string {
        public static final int app_name = 2131755050;

        private string() {
        }
    }

}

