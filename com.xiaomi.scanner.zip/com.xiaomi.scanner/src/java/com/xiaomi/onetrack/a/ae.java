/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.onetrack.a.ad
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.xiaomi.onetrack.a;

import com.xiaomi.onetrack.a.ad;
import com.xiaomi.onetrack.c.l;

class ae
implements Runnable {
    final /* synthetic */ ad a;

    ae(ad ad2) {
        this.a = ad2;
    }

    public void run() {
        l.a().a(0, true);
        l.a().a(1, true);
    }
}

