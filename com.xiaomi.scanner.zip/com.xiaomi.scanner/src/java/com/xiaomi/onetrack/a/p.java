/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.xiaomi.onetrack.a;

import com.xiaomi.onetrack.a.f;
import com.xiaomi.onetrack.h.j;

class p
implements Runnable {
    final /* synthetic */ f a;

    p(f f2) {
        this.a = f2;
    }

    public void run() {
        j.b(f.g(this.a));
    }
}

