/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.onetrack.a;

public interface d {
    public void a(int var1);

    public void a(String var1, String var2);
}

