/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.onetrack.a;

public class b {
    public static final String A = "mac";
    public static final String B = "config_status";
    public static final String C = "scheme";
    public static final String D = "host";
    public static final String E = "port";
    public static final String F = "path";
    public static final String G = "ips";
    public static final String H = "response";
    public static final String I = "status";
    public static final String J = "exception";
    public static final String K = "result";
    public static final String L = "retry";
    public static final String M = "req_ts";
    public static final String N = "req_net";
    public static final String O = "dns";
    public static final String P = "tcp_connect";
    public static final String Q = "req_data_send";
    public static final String R = "handshake";
    public static final String S = "res_first_byte";
    public static final String T = "res_all_byte";
    public static final String U = "duration";
    public static final String V = "net_sdk_ver";
    public static final String W = "last_ver_code";
    public static final String X = "last_ver_name";
    public static final String Y = "cur_ver_code";
    public static final String Z = "last_upgrade_time";
    public static final String a = "ot_login";
    public static final int aa = -1;
    public static final String b = "ot_logout";
    public static final String c = "ot_profile_set";
    public static final String d = "ot_profile_increment";
    public static final String e = "ot_service_quality";
    public static final String f = "onetrack_bug_report";
    public static final String g = "onetrack_pa";
    public static final String h = "onetrack_dau";
    public static final String i = "onetrack_cta_status";
    public static final String j = "onetrack_upgrade";
    public static final String k = "exception";
    public static final String l = "type";
    public static final String m = "message";
    public static final String n = "feature";
    public static final String o = "value";
    public static final String p = "type";
    public static final String q = "class";
    public static final String r = "duration";
    public static final String s = "app_start";
    public static final String t = "app_end";
    public static final int u = 1;
    public static final int v = 2;
    public static final String w = "first_open";
    public static final String x = "imeis";
    public static final String y = "imsis";
    public static final String z = "android_id";
}

