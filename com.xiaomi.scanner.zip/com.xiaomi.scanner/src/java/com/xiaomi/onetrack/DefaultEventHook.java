/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.onetrack;

import com.xiaomi.onetrack.OneTrack;

public class DefaultEventHook
implements OneTrack.IEventHook {
    @Override
    public boolean fillGAID(String string) {
        return false;
    }
}

