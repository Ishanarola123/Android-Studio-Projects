/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IInterface
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.onetrack.h.a.b;

import android.os.IInterface;

public interface a
extends IInterface {
    public String a();
}

