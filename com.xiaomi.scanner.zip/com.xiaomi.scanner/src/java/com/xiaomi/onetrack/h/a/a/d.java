/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 */
package com.xiaomi.onetrack.h.a.a;

import com.xiaomi.onetrack.h.a.a.c;

class d {
    static final /* synthetic */ int[] a;

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    static {
        d.a = new int[c.a.a().length];
        try {
            d.a[c.a.a.ordinal()] = 1;
            ** GOTO lbl-1000
        }
        catch (NoSuchFieldError v0) {
            try lbl-1000: // 2 sources:
            {
                d.a[c.a.b.ordinal()] = 2;
                ** GOTO lbl-1000
            }
            catch (NoSuchFieldError v1) {
                try lbl-1000: // 2 sources:
                {
                    d.a[c.a.c.ordinal()] = 3;
                    ** GOTO lbl-1000
                }
                catch (NoSuchFieldError v2) {
                    try lbl-1000: // 2 sources:
                    {
                        d.a[c.a.d.ordinal()] = 4;
                        ** GOTO lbl-1000
                    }
                    catch (NoSuchFieldError v3) {
                        try lbl-1000: // 2 sources:
                        {
                            d.a[c.a.e.ordinal()] = 5;
                            ** GOTO lbl-1000
                        }
                        catch (NoSuchFieldError v4) {
                            try lbl-1000: // 2 sources:
                            {
                                d.a[c.a.f.ordinal()] = 6;
                                ** GOTO lbl-1000
                            }
                            catch (NoSuchFieldError v5) {
                                try lbl-1000: // 2 sources:
                                {
                                    d.a[c.a.g.ordinal()] = 7;
                                    ** GOTO lbl-1000
                                }
                                catch (NoSuchFieldError v6) {
                                    try lbl-1000: // 2 sources:
                                    {
                                        d.a[c.a.h.ordinal()] = 8;
                                        ** GOTO lbl-1000
                                    }
                                    catch (NoSuchFieldError v7) {
                                        try lbl-1000: // 2 sources:
                                        {
                                            d.a[c.a.i.ordinal()] = 9;
                                            ** GOTO lbl-1000
                                        }
                                        catch (NoSuchFieldError v8) {
                                            try lbl-1000: // 2 sources:
                                            {
                                                d.a[c.a.j.ordinal()] = 10;
                                                ** GOTO lbl-1000
                                            }
                                            catch (NoSuchFieldError v9) {
                                                try lbl-1000: // 2 sources:
                                                {
                                                    d.a[c.a.k.ordinal()] = 11;
                                                    ** GOTO lbl-1000
                                                }
                                                catch (NoSuchFieldError v10) {
                                                    try lbl-1000: // 2 sources:
                                                    {
                                                        d.a[c.a.l.ordinal()] = 12;
                                                        ** GOTO lbl-1000
                                                    }
                                                    catch (NoSuchFieldError v11) {
                                                        try lbl-1000: // 2 sources:
                                                        {
                                                            d.a[c.a.m.ordinal()] = 13;
                                                            ** GOTO lbl-1000
                                                        }
                                                        catch (NoSuchFieldError v12) {
                                                            try lbl-1000: // 2 sources:
                                                            {
                                                                d.a[c.a.n.ordinal()] = 14;
                                                                ** GOTO lbl-1000
                                                            }
                                                            catch (NoSuchFieldError v13) {
                                                                try lbl-1000: // 2 sources:
                                                                {
                                                                    d.a[c.a.o.ordinal()] = 15;
                                                                    ** GOTO lbl-1000
                                                                }
                                                                catch (NoSuchFieldError v14) {
                                                                    try lbl-1000: // 2 sources:
                                                                    {
                                                                        d.a[c.a.p.ordinal()] = 16;
                                                                        return;
                                                                    }
                                                                    catch (NoSuchFieldError v15) {}
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

