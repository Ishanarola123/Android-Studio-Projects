/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.xiaomi.onetrack.h;

import com.xiaomi.onetrack.h.q;

final class r
implements q.a {
    final /* synthetic */ boolean a;

    r(boolean bl) {
        this.a = bl;
    }

    @Override
    public boolean a(Object object) {
        if (this.a) {
            return q.a(object);
        }
        return q.b(object);
    }
}

