/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.xiaomi.onetrack.h;

import com.xiaomi.onetrack.h.q;

final class s
implements q.a {
    s() {
    }

    @Override
    public boolean a(Object object) {
        return q.c(object);
    }
}

