/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IInterface
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.onetrack.h.a.b;

import android.os.IInterface;

public interface c
extends IInterface {
    public String a();

    public String a(String var1);

    public String b();

    public String b(String var1);

    public boolean c();
}

