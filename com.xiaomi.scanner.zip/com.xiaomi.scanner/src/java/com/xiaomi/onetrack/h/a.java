/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.onetrack.h;

public class a {
    public static final String a = "com.miui.analytics";
    public static final String b = "1111111111111111111";
    public static final String c = "onetrack_active";
    public static final String d = "onetrack_usage";
    public static final String e = "onetrack_app_stat";
    public static final String f = "onetrack_bug_report";
    public static final String g = "";
    public static final String h = "analytics_bugreport";
}

