/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Long
 *  java.lang.Object
 *  java.util.ArrayList
 *  org.json.JSONArray
 */
package com.xiaomi.onetrack.c;

import java.util.ArrayList;
import org.json.JSONArray;

public class f {
    public JSONArray a;
    public int b;
    public ArrayList<Long> c;
    public boolean d;

    public f(JSONArray jSONArray, int n2, ArrayList<Long> arrayList, boolean bl) {
        this.a = jSONArray;
        this.b = n2;
        this.c = arrayList;
        this.d = bl;
    }
}

