/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.xiaomi.onetrack.c;

public class i {
    public static final int a = 0;
    public static final int b = -2;
    public static final int c = -3;
    public static final int d = -4;
}

