/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 */
package com.xiaomi.onetrack;

import android.content.Context;
import com.xiaomi.onetrack.OneTrack;
import com.xiaomi.onetrack.g.c;

public class OTUtil {
    public static OneTrack.NetType getNetWorkType(Context context) {
        return c.a(context);
    }
}

