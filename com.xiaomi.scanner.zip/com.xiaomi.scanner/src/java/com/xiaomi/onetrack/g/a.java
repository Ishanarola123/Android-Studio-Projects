/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.onetrack.g;

public class a {
    public static final int a = 0;
    public static final String b = "data";
    public static final String c = "msg";
    public static final String d = "code";
    public static final String e = "hash";
}

