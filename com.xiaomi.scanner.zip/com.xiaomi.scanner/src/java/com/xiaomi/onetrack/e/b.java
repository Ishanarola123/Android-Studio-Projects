/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.onetrack.e.a
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.onetrack.e;

import com.xiaomi.onetrack.e.a;

public class b {
    public static com.xiaomi.onetrack.f.b a(String string2, String string3, String string4, String string5) {
        return new a(string2, string3, string4, string5);
    }
}

