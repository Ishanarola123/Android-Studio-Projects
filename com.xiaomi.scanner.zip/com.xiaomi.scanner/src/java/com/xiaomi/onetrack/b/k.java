/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.onetrack.b;

public class k {
    public static final String a = "oa";
    public static final String b = "ov";
    public static final String c = "ob";
    public static final String d = "ii";
    public static final String e = "sv";
    public static final String f = "av";
    public static final String g = "ml";
    public static final String h = "re";
    public static final String i = "ail";
    public static final String j = "sender";
    public static final String k = "hs";
    public static final String l = "platform";
}

