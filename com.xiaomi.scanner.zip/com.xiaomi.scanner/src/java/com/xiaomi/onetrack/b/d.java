/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.xiaomi.onetrack.b;

import com.xiaomi.onetrack.b.c;

final class d
implements Runnable {
    d() {
    }

    public void run() {
        c.d();
    }
}

