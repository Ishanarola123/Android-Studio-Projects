/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package com.xiaomi.onetrack.b;

import com.xiaomi.onetrack.b.a;

final class b
implements Runnable {
    final /* synthetic */ String a;

    b(String string2) {
        this.a = string2;
    }

    public void run() {
        a.b(this.a);
    }
}

