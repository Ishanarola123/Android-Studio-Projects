/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.xiaomi.onetrack;

public class OneTrackException
extends Exception {
    public OneTrackException() {
    }

    public OneTrackException(String string2) {
        super(string2);
    }

    public OneTrackException(String string2, Throwable throwable) {
        super(string2, throwable);
    }

    public OneTrackException(Throwable throwable) {
        super(throwable);
    }
}

