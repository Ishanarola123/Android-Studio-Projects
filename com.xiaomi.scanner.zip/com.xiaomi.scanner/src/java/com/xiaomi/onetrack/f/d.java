/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.onetrack.f;

import com.xiaomi.onetrack.f.e;
import com.xiaomi.onetrack.h.h;

public class d {
    private static final String a = "EventTrack";

    public static void a(String string2, String string3, String string4, String string5) {
        h.a(new e(string2, string3, string4, string5));
    }
}

