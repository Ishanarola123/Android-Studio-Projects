/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.scanner;

public final class BuildConfig {
    public static final String APPLICATION_ID = "com.xiaomi.scanner";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FILES_AUTHORITY = "com.xiaomi.scanner.fileprovider";
    public static final String FLAVOR = "market";
    public static final int VERSION_CODE = 13220218;
    public static final String VERSION_NAME = "13.2202.18";
}

