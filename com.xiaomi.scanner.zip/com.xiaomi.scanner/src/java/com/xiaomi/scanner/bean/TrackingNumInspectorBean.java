/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.scanner.bean;

public class TrackingNumInspectorBean {
    private String data;

    public String getData() {
        return this.data;
    }

    public void setData(String string2) {
        this.data = string2;
    }
}

