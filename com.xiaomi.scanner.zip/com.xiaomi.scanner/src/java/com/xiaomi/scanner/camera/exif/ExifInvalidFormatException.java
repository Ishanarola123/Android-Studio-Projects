/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.String
 */
package com.xiaomi.scanner.camera.exif;

public class ExifInvalidFormatException
extends Exception {
    public ExifInvalidFormatException(String string2) {
        super(string2);
    }
}

