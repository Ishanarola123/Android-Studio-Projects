/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.xiaomi.scanner.camera.exif;

public interface IfdId {
    public static final int TYPE_IFD_0 = 0;
    public static final int TYPE_IFD_1 = 1;
    public static final int TYPE_IFD_COUNT = 5;
    public static final int TYPE_IFD_EXIF = 2;
    public static final int TYPE_IFD_GPS = 4;
    public static final int TYPE_IFD_INTEROPERABILITY = 3;
}

