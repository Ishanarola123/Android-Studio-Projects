/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 */
package com.xiaomi.scanner.camera;

public class CameraDisabledException
extends Exception {
}

