/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.scanner.settings;

public class SettingsScopeNamespaces {
    public static final String MODULE_BUSINESS_CARD = "module_business_card";
    public static final String MODULE_CARSHOME = "module_carshome";
    public static final String MODULE_CLASSES = "module_classes";
    public static final String MODULE_CODE = "module_code";
    public static final String MODULE_DOCUMENT = "module_document";
    public static final String MODULE_FOOD = "module_food";
    public static final String MODULE_JD_SHOPPING = "module_jd_shopping";
    public static final String MODULE_PLANT = "module_plant";
    public static final String MODULE_SHOPPING = "module_shopping";
    public static final String MODULE_STORE = "module_store";
    public static final String MODULE_STUDY = "module_study";
    public static final String MODULE_TRANSLATION = "module_translation";
}

