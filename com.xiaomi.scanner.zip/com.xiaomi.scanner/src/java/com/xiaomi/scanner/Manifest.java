/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.scanner;

public final class Manifest {

    public static final class permission {
        public static final String RECEIVER = "com.xiaomi.scanner.receiver.RECEIVER";
    }

}

