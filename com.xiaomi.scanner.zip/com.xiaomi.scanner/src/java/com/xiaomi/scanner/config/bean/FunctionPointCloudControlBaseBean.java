/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.xiaomi.scanner.config.bean;

import com.xiaomi.scanner.config.bean.FunctionPointControlBean;

public class FunctionPointCloudControlBaseBean {
    private FunctionPointControlBean businessCardBean;
    private FunctionPointControlBean carsHomeBean;
    private FunctionPointControlBean codeBean;
    private FunctionPointControlBean documentBean;
    private FunctionPointControlBean foodBean;
    private FunctionPointControlBean internalTestSwitchBean;
    private FunctionPointControlBean isCanscanMiLogoBean;
    private FunctionPointControlBean isShowClassBean;
    private FunctionPointControlBean isShowFoodLogoBean;
    private FunctionPointControlBean isShowSweepThePlantLogoBean;
    private FunctionPointControlBean photoShoppingBean;
    private FunctionPointControlBean plantBean;
    private FunctionPointControlBean pptBean;
    private FunctionPointControlBean storeBean;
    private FunctionPointControlBean studyBean;
    private FunctionPointControlBean translationBean;
    private FunctionPointControlBean xiaoaiBean;

    public FunctionPointControlBean getBusinessCardBean() {
        return this.businessCardBean;
    }

    public FunctionPointControlBean getCarsHomeBean() {
        return this.carsHomeBean;
    }

    public FunctionPointControlBean getCodeBean() {
        return this.codeBean;
    }

    public FunctionPointControlBean getDocumentBean() {
        return this.documentBean;
    }

    public FunctionPointControlBean getFoodBean() {
        return this.foodBean;
    }

    public FunctionPointControlBean getInternalTestSwitchBean() {
        return this.internalTestSwitchBean;
    }

    public FunctionPointControlBean getIsCanscanMiLogoBean() {
        return this.isCanscanMiLogoBean;
    }

    public FunctionPointControlBean getIsShowClassBean() {
        return this.isShowClassBean;
    }

    public FunctionPointControlBean getIsShowFoodLogoBean() {
        return this.isShowFoodLogoBean;
    }

    public FunctionPointControlBean getIsShowSweepThePlantLogoBean() {
        return this.isShowSweepThePlantLogoBean;
    }

    public FunctionPointControlBean getPhotoShoppingBean() {
        return this.photoShoppingBean;
    }

    public FunctionPointControlBean getPlantBean() {
        return this.plantBean;
    }

    public FunctionPointControlBean getPptBean() {
        return this.pptBean;
    }

    public FunctionPointControlBean getStoreBean() {
        return this.storeBean;
    }

    public FunctionPointControlBean getStudyBean() {
        return this.studyBean;
    }

    public FunctionPointControlBean getTranslationBean() {
        return this.translationBean;
    }

    public FunctionPointControlBean getXiaoaiBean() {
        return this.xiaoaiBean;
    }

    public void setBusinessCardBean(FunctionPointControlBean functionPointControlBean) {
        this.businessCardBean = functionPointControlBean;
    }

    public void setCarsHomeBean(FunctionPointControlBean functionPointControlBean) {
        this.carsHomeBean = functionPointControlBean;
    }

    public void setCodeBean(FunctionPointControlBean functionPointControlBean) {
        this.codeBean = functionPointControlBean;
    }

    public void setDocumentBean(FunctionPointControlBean functionPointControlBean) {
        this.documentBean = functionPointControlBean;
    }

    public void setFoodBean(FunctionPointControlBean functionPointControlBean) {
        this.foodBean = functionPointControlBean;
    }

    public void setInternalTestSwitchBean(FunctionPointControlBean functionPointControlBean) {
        this.internalTestSwitchBean = functionPointControlBean;
    }

    public void setIsCanscanMiLogoBean(FunctionPointControlBean functionPointControlBean) {
        this.isCanscanMiLogoBean = functionPointControlBean;
    }

    public void setIsShowClassBean(FunctionPointControlBean functionPointControlBean) {
        this.isShowClassBean = functionPointControlBean;
    }

    public void setIsShowFoodLogoBean(FunctionPointControlBean functionPointControlBean) {
        this.isShowFoodLogoBean = functionPointControlBean;
    }

    public void setIsShowSweepThePlantLogoBean(FunctionPointControlBean functionPointControlBean) {
        this.isShowSweepThePlantLogoBean = functionPointControlBean;
    }

    public void setPhotoShoppingBean(FunctionPointControlBean functionPointControlBean) {
        this.photoShoppingBean = functionPointControlBean;
    }

    public void setPlantBean(FunctionPointControlBean functionPointControlBean) {
        this.plantBean = functionPointControlBean;
    }

    public void setPptBean(FunctionPointControlBean functionPointControlBean) {
        this.pptBean = functionPointControlBean;
    }

    public void setStoreBean(FunctionPointControlBean functionPointControlBean) {
        this.storeBean = functionPointControlBean;
    }

    public void setStudyBean(FunctionPointControlBean functionPointControlBean) {
        this.studyBean = functionPointControlBean;
    }

    public void setTranslationBean(FunctionPointControlBean functionPointControlBean) {
        this.translationBean = functionPointControlBean;
    }

    public void setXiaoaiBean(FunctionPointControlBean functionPointControlBean) {
        this.xiaoaiBean = functionPointControlBean;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FunctionPointCloudControlBaseBean{documentBean=");
        stringBuilder.append((Object)this.documentBean);
        stringBuilder.append(", studyBean=");
        stringBuilder.append((Object)this.studyBean);
        stringBuilder.append(", codeBean=");
        stringBuilder.append((Object)this.codeBean);
        stringBuilder.append(", plantBean=");
        stringBuilder.append((Object)this.plantBean);
        stringBuilder.append(", photoShoppingBean=");
        stringBuilder.append((Object)this.photoShoppingBean);
        stringBuilder.append(", businessCardBean=");
        stringBuilder.append((Object)this.businessCardBean);
        stringBuilder.append(", translationBean=");
        stringBuilder.append((Object)this.translationBean);
        stringBuilder.append(", pptBean=");
        stringBuilder.append((Object)this.pptBean);
        stringBuilder.append(", foodBean=");
        stringBuilder.append((Object)this.foodBean);
        stringBuilder.append(", storeBean=");
        stringBuilder.append((Object)this.storeBean);
        stringBuilder.append(", internalTestSwitchBean=");
        stringBuilder.append((Object)this.internalTestSwitchBean);
        stringBuilder.append(", carsHomeBean=");
        stringBuilder.append((Object)this.carsHomeBean);
        stringBuilder.append(", xiaoaiBean=");
        stringBuilder.append((Object)this.xiaoaiBean);
        stringBuilder.append(", isShowSweepThePlantLogoBean=");
        stringBuilder.append((Object)this.isShowSweepThePlantLogoBean);
        stringBuilder.append(", isShowFoodLogoBean=");
        stringBuilder.append((Object)this.isShowFoodLogoBean);
        stringBuilder.append(", isCanscanMiLogoBean=");
        stringBuilder.append((Object)this.isCanscanMiLogoBean);
        stringBuilder.append(", isShowClassBean=");
        stringBuilder.append((Object)this.isShowClassBean);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}

