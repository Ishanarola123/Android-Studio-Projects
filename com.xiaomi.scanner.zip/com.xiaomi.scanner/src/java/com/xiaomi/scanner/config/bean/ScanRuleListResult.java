/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  java.util.Map
 */
package com.xiaomi.scanner.config.bean;

import java.util.List;
import java.util.Map;

public class ScanRuleListResult {
    public List<String> allCanPayRules;
    public List<String> scanAlipayRules;
    public List<String> scanMiBiPayRules;
    public List<String> scanMipayRules;
    public Map<String, String> scanTipMap;
    public List<String> wechatJumpRules;
}

