/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.tencent.mm.opensdk.modelbiz;

public class AddCardToWXCardPackage {
    private static final String TAG = "MicroMsg.AddCardToWXCardPackage";

    public static final class WXCardItem {
        public String cardExtMsg;
        public String cardId;
        public int cardState;
    }

}

