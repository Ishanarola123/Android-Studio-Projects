/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.tencent.mm.opensdk.modelbiz;

public class HandleScanResult {
}

