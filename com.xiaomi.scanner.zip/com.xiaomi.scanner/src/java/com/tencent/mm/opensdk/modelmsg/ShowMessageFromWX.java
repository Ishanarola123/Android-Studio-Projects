/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.tencent.mm.opensdk.modelmsg;

public class ShowMessageFromWX {
    private ShowMessageFromWX() {
    }
}

