/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.String
 */
package com.tencent.mm.opensdk.openapi;

import android.content.Context;
import com.tencent.mm.opensdk.openapi.BaseWXApiImplV10;

final class WXApiImplV10
extends BaseWXApiImplV10 {
    WXApiImplV10(Context context, String string, boolean bl) {
        super(context, string, bl);
    }
}

