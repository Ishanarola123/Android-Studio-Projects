/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.tencent.mm.opensdk.utils;

public interface ILog {
    public void d(String var1, String var2);

    public void e(String var1, String var2);

    public void i(String var1, String var2);

    public void v(String var1, String var2);

    public void w(String var1, String var2);
}

